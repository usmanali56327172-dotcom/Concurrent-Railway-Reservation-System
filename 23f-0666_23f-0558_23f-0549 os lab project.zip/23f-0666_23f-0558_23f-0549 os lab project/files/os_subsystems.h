/*
 * os_subsystems.h
 * ─────────────────────────────────────────────────────────────────────────────
 * All OS simulation subsystems in one file:
 *   1. ResourceManager   – RAM and CPU core allocation
 *   2. ProcessManager    – PCB lifecycle and Ready Queue
 *   3. Scheduler         – FCFS, Round Robin, Priority
 *   4. IPCChannel        – Inter-Process Communication (message queue + pipe sim)
 *   5. InterruptHandler  – OS interrupt raising and handling
 * ─────────────────────────────────────────────────────────────────────────────
 */
#pragma once

#include "os_core.h"
#include <deque>
#include <queue>
#include <vector>
#include <algorithm>
#include <thread>
#include <chrono>
#include <functional>
#include <condition_variable>
#include <sstream>

// ═══════════════════════════════════════════════════════════════════════════════
//  1. RESOURCE MANAGER
//     Tracks RAM and CPU cores. Must be checked before any process is created.
//     This is a kernel-mode operation – users cannot call it directly.
// ═══════════════════════════════════════════════════════════════════════════════
class ResourceManager {
public:
    explicit ResourceManager(SystemConfig& cfg) : cfg_(cfg) {
        cores_.assign(cfg_.totalCores, true); // all cores free at boot
    }

    /*
     * allocate() – reserve memMB of RAM and one CPU core.
     * Returns the core index on success, -1 if resources unavailable.
     */
    int allocate(long long memMB) {
        std::lock_guard<std::mutex> lk(mtx_);
        long long free = cfg_.totalRAM_MB - cfg_.usedRAM_MB;
        if (free < memMB) {
            LOG("RESOURCE: Not enough RAM. Need=" + std::to_string(memMB)
                + "MB Free=" + std::to_string(free) + "MB");
            return -1;
        }
        int core = firstFreeCore();
        if (core == -1) {
            LOG("RESOURCE: All CPU cores busy");
            return -1;
        }
        cfg_.usedRAM_MB += memMB;
        cores_[core] = false;
        cfg_.usedCores++;
        LOG("RESOURCE: Allocated " + std::to_string(memMB) + "MB + Core " + std::to_string(core));
        return core;
    }

    // Release resources back to the pool after process ends
    void release(long long memMB, int core) {
        std::lock_guard<std::mutex> lk(mtx_);
        cfg_.usedRAM_MB = std::max(0LL, cfg_.usedRAM_MB - memMB);
        if (core >= 0 && core < (int)cores_.size()) {
            cores_[core] = true;
            cfg_.usedCores--;
        }
        LOG("RESOURCE: Released " + std::to_string(memMB) + "MB + Core " + std::to_string(core));
    }

    void printStatus() const {
        std::cout << "\n  RAM  : " << cfg_.usedRAM_MB << " / " << cfg_.totalRAM_MB << " MB used\n";
        std::cout << "  Disk : " << cfg_.totalDisk_GB << " GB total\n";
        std::cout << "  Cores: " << cfg_.usedCores << " / " << cfg_.totalCores << " in use\n";
    }

private:
    int firstFreeCore() const {
        for (int i = 0; i < (int)cores_.size(); i++)
            if (cores_[i]) return i;
        return -1;
    }

    SystemConfig&    cfg_;
    std::vector<bool> cores_;
    std::mutex       mtx_;
};

// ═══════════════════════════════════════════════════════════════════════════════
//  2. PROCESS MANAGER
//     Creates and tracks all PCBs. Maintains the Ready Queue.
//     State transitions: NEW -> READY -> RUNNING -> TERMINATED/BLOCKED
// ═══════════════════════════════════════════════════════════════════════════════
class ProcessManager {
public:
    ProcessManager() : nextPID_(1) {}

    // Create a new PCB and register it in the process table
    int createProcess(const std::string& name, const std::string& action,
                      int memMB = 64, int burst = 150, int priority = 1) {
        std::lock_guard<std::mutex> lk(mtx_);
        PCB p;
        p.pid           = nextPID_++;
        p.name          = name;
        p.action        = action;
        p.memoryMB      = memMB;
        p.burstTime     = burst;
        p.remainingTime = burst;
        p.priority      = priority;
        p.state         = ProcessState::NEW;
        table_.push_back(p);
        LOG("PROCESS: Created PID=" + std::to_string(p.pid)
            + " [" + action + "] name=" + name);
        return p.pid;
    }

    // Transition process to READY and add to ready queue
    void makeReady(int pid) {
        std::lock_guard<std::mutex> lk(mtx_);
        PCB* p = find(pid);
        if (!p) return;
        p->state = ProcessState::READY;
        readyQueue_.push_back(pid);
        LOG("PROCESS: PID=" + std::to_string(pid) + " -> READY");
    }

    // Pop next PID from front of ready queue (FCFS order)
    int dequeue() {
        std::lock_guard<std::mutex> lk(mtx_);
        if (readyQueue_.empty()) return -1;
        int pid = readyQueue_.front();
        readyQueue_.pop_front();
        return pid;
    }

    // Append PID to back of ready queue (used by Round Robin preemption)
    void requeue(int pid) {
        std::lock_guard<std::mutex> lk(mtx_);
        readyQueue_.push_back(pid);
    }

    // ── Priority scheduling: sort ready queue by PCB priority field ──────────
    void sortByPriority() {
        std::lock_guard<std::mutex> lk(mtx_);
        std::stable_sort(readyQueue_.begin(), readyQueue_.end(),
            [&](int a, int b) {
                PCB* pa = find(a); PCB* pb = find(b);
                if (!pa || !pb) return false;
                return pa->priority < pb->priority; // lower number = higher priority
            });
        LOG("SCHEDULER: Ready queue sorted by priority");
    }

    void setState(int pid, ProcessState s) {
        std::lock_guard<std::mutex> lk(mtx_);
        PCB* p = find(pid);
        if (!p) return;
        p->state = s;
        LOG("PROCESS: PID=" + std::to_string(pid) + " -> " + stateStr(s));
    }

    // Kernel-only: forcefully terminate any process
    bool forceTerminate(int pid) {
        std::lock_guard<std::mutex> lk(mtx_);
        PCB* p = find(pid);
        if (!p || p->state == ProcessState::TERMINATED) return false;
        p->state = ProcessState::TERMINATED;
        readyQueue_.erase(
            std::remove(readyQueue_.begin(), readyQueue_.end(), pid),
            readyQueue_.end());
        LOG("PROCESS: PID=" + std::to_string(pid) + " force-terminated by kernel");
        return true;
    }

    PCB* get(int pid) {
        std::lock_guard<std::mutex> lk(mtx_);
        return find(pid);
    }

    bool queueEmpty() {
        std::lock_guard<std::mutex> lk(mtx_);
        return readyQueue_.empty();
    }

    int queueSize() {
        std::lock_guard<std::mutex> lk(mtx_);
        return (int)readyQueue_.size();
    }

    /*
     * unblockAll() – moves every BLOCKED process back to READY state
     * and re-enqueues it. Called after an interrupt is resolved so the
     * CPU can schedule those processes again (BLOCKED -> READY recovery).
     */
    int unblockAll() {
        std::lock_guard<std::mutex> lk(mtx_);
        int count = 0;
        for (auto& p : table_) {
            if (p.state == ProcessState::BLOCKED) {
                p.state = ProcessState::READY;
                readyQueue_.push_back(p.pid);
                LOG("PROCESS: PID=" + std::to_string(p.pid) + " BLOCKED -> READY (recovered)");
                count++;
            }
        }
        return count;
    }

    /*
     * blockedCount() – returns how many processes are currently BLOCKED.
     * Used by the kernel menu to show blocked process status.
     */
    int blockedCount() {
        std::lock_guard<std::mutex> lk(mtx_);
        int cnt = 0;
        for (const auto& p : table_)
            if (p.state == ProcessState::BLOCKED) cnt++;
        return cnt;
    }

    void printTable() const {
        std::lock_guard<std::mutex> lk(mtx_);
        printf("\n  %-5s %-20s %-10s %-5s %s\n",
               "PID", "Name", "Action", "Pri", "State");
        printf("  %-5s %-20s %-10s %-5s %s\n",
               "-----", "--------------------", "----------", "-----", "-----------");
        for (const auto& p : table_)
            printf("  %-5d %-20s %-10s %-5d %s\n",
                   p.pid, p.name.c_str(), p.action.c_str(),
                   p.priority, stateStr(p.state).c_str());
        std::cout << "\n";
    }

    /*
     * getSnapshots() – returns a lightweight copy of all PCBs for the GUI.
     * Used by GraphicsUI::drawProcessTable() to render the color-coded table.
     * Returns a vector of PCB copies so the GUI does not need to hold the lock.
     */
    std::vector<PCB> getSnapshots() const {
        std::lock_guard<std::mutex> lk(mtx_);
        return table_;   // value copy – safe after lock is released
    }

private:
    // Internal find without locking (caller holds lock)
    PCB* find(int pid) {
        for (auto& p : table_)
            if (p.pid == pid) return &p;
        return nullptr;
    }

    mutable std::mutex mtx_;
    std::atomic<int>   nextPID_;
    std::deque<int>    readyQueue_;
    std::vector<PCB>   table_;
};

// ═══════════════════════════════════════════════════════════════════════════════
//  3. CPU SCHEDULER
//     Implements FCFS, Round Robin, and Priority scheduling.
//     Dispatches the next ready process, simulates CPU burst, then
//     calls the provided execute function (which does the reservation logic).
// ═══════════════════════════════════════════════════════════════════════════════
class Scheduler {
public:
    using Task = std::function<void(PCB&)>;

    Scheduler(ProcessManager& pm, ResourceManager& rm, SystemConfig& cfg)
        : pm_(pm), rm_(rm), cfg_(cfg), algo_(SchedulingAlgo::FCFS) {}

    void setAlgo(SchedulingAlgo a) {
        algo_ = a;
        LOG("SCHEDULER: Algorithm -> " + algoName());
    }

    std::string algoName() const {
        switch (algo_) {
            case SchedulingAlgo::FCFS:        return "FCFS";
            case SchedulingAlgo::ROUND_ROBIN: return "Round Robin";
            case SchedulingAlgo::PRIORITY:    return "Priority";
            default: return "?";
        }
    }

    SchedulingAlgo currentAlgo() const { return algo_; }

    /*
     * dispatch() – one scheduling cycle.
     * 1. Sort queue if Priority mode
     * 2. Dequeue next PID
     * 3. Allocate resources (RAM + core)
     * 4. Set RUNNING, simulate burst, call task function
     * 5. Release resources, set TERMINATED
     */
    void dispatch(Task task) {
        if (pm_.queueEmpty()) return;

        // Priority: sort before picking
        if (algo_ == SchedulingAlgo::PRIORITY)
            pm_.sortByPriority();

        int pid = pm_.dequeue();
        if (pid == -1) return;

        PCB* pcb = pm_.get(pid);
        if (!pcb || pcb->state == ProcessState::TERMINATED) return;

        // Resource check (kernel validates before CPU time is given)
        int core = rm_.allocate(pcb->memoryMB);
        if (core == -1) {
            pm_.setState(pid, ProcessState::BLOCKED);
            pm_.requeue(pid);
            std::cout << "\033[33m  [SCHEDULER] PID=" << pid
                      << " BLOCKED – insufficient resources\033[0m\n";
            return;
        }

        pcb->cpuCore = core;
        pm_.setState(pid, ProcessState::RUNNING);
        LOG("SCHEDULER [" + algoName() + "]: Dispatch PID=" + std::to_string(pid)
            + " Core=" + std::to_string(core));

        if (algo_ == SchedulingAlgo::ROUND_ROBIN)
            runRoundRobin(*pcb, task, core);
        else
            runToCompletion(*pcb, task, core);
    }

private:
    // FCFS / Priority: give full burst then terminate
    void runToCompletion(PCB& p, Task& task, int core) {
        std::this_thread::sleep_for(std::chrono::milliseconds(p.burstTime));
        task(p);
        pm_.setState(p.pid, ProcessState::TERMINATED);
        rm_.release(p.memoryMB, core);
        LOG("SCHEDULER: PID=" + std::to_string(p.pid) + " done (" + algoName() + ")");
    }

    // Round Robin: run one time quantum, requeue if burst not finished
    void runRoundRobin(PCB& p, Task& task, int core) {
        int slice = std::min(p.remainingTime, cfg_.timeQuantum);
        std::this_thread::sleep_for(std::chrono::milliseconds(slice));
        p.remainingTime -= slice;

        if (p.remainingTime <= 0) {
            task(p);
            pm_.setState(p.pid, ProcessState::TERMINATED);
            rm_.release(p.memoryMB, core);
            LOG("SCHEDULER: PID=" + std::to_string(p.pid) + " done (RR)");
        } else {
            rm_.release(p.memoryMB, core);
            pm_.setState(p.pid, ProcessState::READY);
            pm_.requeue(p.pid);
            LOG("SCHEDULER: PID=" + std::to_string(p.pid)
                + " preempted – remaining=" + std::to_string(p.remainingTime) + "ms");
        }
    }

    ProcessManager& pm_;
    ResourceManager& rm_;
    SystemConfig&   cfg_;
    SchedulingAlgo  algo_;
};

// ═══════════════════════════════════════════════════════════════════════════════
//  4. IPC CHANNEL  (Inter-Process Communication)
//     Simulates both a Message Queue and a Pipe between processes.
//
//     Message Queue: any process pushes a message; any other pops it.
//     Pipe: one writer end, one reader end (simulated with a shared buffer).
//     Both are protected by mutex + condition_variable for blocking reads.
// ═══════════════════════════════════════════════════════════════════════════════
struct IPCMessage {
    int         senderPID;
    int         receiverPID;  // -1 = broadcast
    std::string content;
};

class IPCChannel {
public:
    // ── Message Queue ────────────────────────────────────────────────────────
    void sendMessage(int from, int to, const std::string& msg) {
        {
            std::lock_guard<std::mutex> lk(mqMtx_);
            msgQueue_.push_back({from, to, msg});
        }
        mqCv_.notify_all();
        LOG("IPC [MSG_QUEUE]: PID=" + std::to_string(from)
            + " -> PID=" + std::to_string(to) + " | " + msg);
    }

    // Blocking read: waits until a message for 'forPID' (or broadcast) arrives
    IPCMessage receiveMessage(int forPID, int timeoutMs = 2000) {
        std::unique_lock<std::mutex> lk(mqMtx_);
        bool got = mqCv_.wait_for(lk, std::chrono::milliseconds(timeoutMs),
            [&] {
                for (auto& m : msgQueue_)
                    if (m.receiverPID == forPID || m.receiverPID == -1)
                        return true;
                return false;
            });

        if (!got) return {-1, forPID, "TIMEOUT"};

        for (auto it = msgQueue_.begin(); it != msgQueue_.end(); ++it) {
            if (it->receiverPID == forPID || it->receiverPID == -1) {
                IPCMessage m = *it;
                msgQueue_.erase(it);
                LOG("IPC [MSG_QUEUE]: PID=" + std::to_string(forPID) + " received: " + m.content);
                return m;
            }
        }
        return {-1, forPID, "EMPTY"};
    }

    // ── Pipe ─────────────────────────────────────────────────────────────────
    // One process writes into the pipe; another reads from it.
    void pipeWrite(int pid, const std::string& data) {
        std::lock_guard<std::mutex> lk(pipeMtx_);
        pipe_ += data + "\n";
        LOG("IPC [PIPE]: PID=" + std::to_string(pid) + " wrote: " + data);
    }

    std::string pipeRead(int pid) {
        std::lock_guard<std::mutex> lk(pipeMtx_);
        std::string out = pipe_;
        pipe_.clear();
        LOG("IPC [PIPE]: PID=" + std::to_string(pid) + " read pipe");
        return out.empty() ? "(pipe empty)" : out;
    }

    void printMessageQueue() const {
        std::lock_guard<std::mutex> lk(mqMtx_);
        if (msgQueue_.empty()) { std::cout << "  Message queue is empty.\n"; return; }
        printf("  %-8s %-8s %s\n", "FROM", "TO", "MESSAGE");
        printf("  %-8s %-8s %s\n", "--------", "--------", "-------------------------");
        for (const auto& m : msgQueue_)
            printf("  %-8d %-8d %s\n", m.senderPID, m.receiverPID, m.content.c_str());
    }

private:
    mutable std::mutex      mqMtx_;
    std::condition_variable mqCv_;
    std::deque<IPCMessage>  msgQueue_;

    mutable std::mutex      pipeMtx_;
    std::string             pipe_;
};

// ═══════════════════════════════════════════════════════════════════════════════
//  5. INTERRUPT HANDLER
//     OS-level interrupt management.
//     When an interrupt fires, the currently RUNNING process moves to BLOCKED.
//     The CPU is then free to pick another READY process.
// ═══════════════════════════════════════════════════════════════════════════════
class InterruptHandler {
public:
    explicit InterruptHandler(ProcessManager& pm)
        : pm_(pm), pending_(InterruptType::NONE), shuttingDown_(false) {}

    // Raise an interrupt (can be called from any thread)
    void raise(InterruptType t) {
        pending_.store(t);
        if (t == InterruptType::SYSTEM_SHUTDOWN) shuttingDown_ = true;
        std::string name = intName(t);
        LOG("INTERRUPT: Raised -> " + name);
        std::cout << "\033[35m  [INT] " << name << "\033[0m\n";
    }

    /*
     * handle() – processes the pending interrupt for the given running PID.
     * TICKET_CANCEL  : process moves BLOCKED, then recovers to READY after
     *                  a short delay (simulates waiting for cancellation ISR).
     * BOOKING_TIMEOUT: process is TERMINATED (unrecoverable).
     * SYSTEM_SHUTDOWN: broadcast – triggers OS halt.
     */
    void handle(int runningPID) {
        InterruptType t = pending_.exchange(InterruptType::NONE);
        if (t == InterruptType::NONE) return;

        switch (t) {
            case InterruptType::TICKET_CANCEL:
                std::cout << "\033[35m  [INT HANDLER] TICKET_CANCEL – PID="
                          << runningPID << " -> BLOCKED\033[0m\n";
                pm_.setState(runningPID, ProcessState::BLOCKED);
                // After interrupt service routine completes, process returns to READY
                std::this_thread::sleep_for(std::chrono::milliseconds(200));
                pm_.setState(runningPID, ProcessState::READY);
                pm_.requeue(runningPID);
                std::cout << "\033[35m  [INT HANDLER] ISR done – PID="
                          << runningPID << " -> READY (recovered)\033[0m\n";
                LOG("INTERRUPT: PID=" + std::to_string(runningPID) + " recovered BLOCKED->READY");
                break;
            case InterruptType::BOOKING_TIMEOUT:
                std::cout << "\033[35m  [INT HANDLER] TIMEOUT – PID="
                          << runningPID << " -> TERMINATED\033[0m\n";
                pm_.setState(runningPID, ProcessState::TERMINATED);
                break;
            case InterruptType::SYSTEM_SHUTDOWN:
                std::cout << "\033[35m  [INT HANDLER] SHUTDOWN received\033[0m\n";
                break;
            default: break;
        }
    }

    /*
     * unblockProcesses() – kernel command to manually recover all BLOCKED
     * processes back to READY state. Returns count of recovered processes.
     */
    int unblockProcesses() {
        int n = pm_.unblockAll();
        if (n > 0) {
            std::cout << "\033[35m  [INT HANDLER] Recovered " << n
                      << " BLOCKED process(es) -> READY\033[0m\n";
            LOG("INTERRUPT: Kernel unblocked " + std::to_string(n) + " processes");
        } else {
            std::cout << "\033[33m  No BLOCKED processes to recover.\033[0m\n";
        }
        return n;
    }

    bool shuttingDown() const { return shuttingDown_.load(); }

private:
    std::string intName(InterruptType t) const {
        switch (t) {
            case InterruptType::TICKET_CANCEL:   return "TICKET_CANCEL";
            case InterruptType::BOOKING_TIMEOUT: return "BOOKING_TIMEOUT";
            case InterruptType::SYSTEM_SHUTDOWN: return "SYSTEM_SHUTDOWN";
            default: return "NONE";
        }
    }

    ProcessManager&            pm_;
    std::atomic<InterruptType> pending_;
    std::atomic<bool>          shuttingDown_;
};
