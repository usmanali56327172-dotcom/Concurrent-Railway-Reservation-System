/*
 * graphics.h
 * ─────────────────────────────────────────────────────────────────────────────
 * BONUS: ncurses-based Graphical TUI for Mini OS Simulator
 *
 * Provides a complete Terminal User Interface using the ncurses library:
 *
 *   GraphicsUI  – Main UI class. Wraps all ncurses calls.
 *     • Animated boot splash with progress bar
 *     • Status bar: mode, algo, queue size, RAM %, cores
 *     • Bordered, colored menu panels (User Mode = cyan, Kernel = red)
 *     • Real-time resource dashboard (RAM bar graph, core grid, seat map)
 *     • Process table with per-state color coding
 *     • Input dialogs with inline prompts
 *     • Seat map rendered as a colored grid
 *     • Banker's Algorithm state visualizer
 *
 * Usage (in main_gui.cpp):
 *   GraphicsUI ui;
 *   ui.boot(cfg);          // animated boot
 *   ui.drawDashboard(...); // resource panel
 *   int ch = ui.menu(...); // show menu, return choice
 *   ui.dialog(...);        // input box
 *
 * Design notes:
 *   - All windows are created fresh per screen; no persistent WINDOW* storage
 *     except the permanent status bar at row 0.
 *   - Colors: pair 1=cyan/black, 2=red/black, 3=green/black,
 *             4=yellow/black, 5=white/black, 6=magenta/black, 7=blue/black
 *   - The original terminal-mode OS (main.cpp) continues to work unchanged.
 *     This file adds a SECOND entry point (main_gui.cpp) that uses GraphicsUI.
 * ─────────────────────────────────────────────────────────────────────────────
 */
#pragma once

#include "os_core.h"
#include "banker.h"
#include <ncurses.h>
#include <string>
#include <vector>
#include <thread>
#include <chrono>
#include <cstring>
#include <algorithm>
#include <sstream>

// ── Color pair IDs ────────────────────────────────────────────────────────────
#define CP_CYAN    1   // cyan on black  – user mode
#define CP_RED     2   // red on black   – kernel mode / error
#define CP_GREEN   3   // green on black – success / free
#define CP_YELLOW  4   // yellow on black – warning / highlight
#define CP_WHITE   5   // white on black – normal text
#define CP_MAGENTA 6   // magenta on black – bonus / special
#define CP_BLUE    7   // blue on black  – info

// ─────────────────────────────────────────────────────────────────────────────
class GraphicsUI {
public:
    // ── Constructor / Destructor ───────────────────────────────────────────────
    GraphicsUI() : statusWin_(nullptr) {
        initscr();
        cbreak();
        noecho();
        keypad(stdscr, TRUE);
        curs_set(0);
        start_color();
        use_default_colors();

        // Define color pairs
        init_pair(CP_CYAN,    COLOR_CYAN,    COLOR_BLACK);
        init_pair(CP_RED,     COLOR_RED,     COLOR_BLACK);
        init_pair(CP_GREEN,   COLOR_GREEN,   COLOR_BLACK);
        init_pair(CP_YELLOW,  COLOR_YELLOW,  COLOR_BLACK);
        init_pair(CP_WHITE,   COLOR_WHITE,   COLOR_BLACK);
        init_pair(CP_MAGENTA, COLOR_MAGENTA, COLOR_BLACK);
        init_pair(CP_BLUE,    COLOR_CYAN,    COLOR_BLUE);

        getmaxyx(stdscr, rows_, cols_);
    }

    ~GraphicsUI() {
        if (statusWin_) { delwin(statusWin_); statusWin_ = nullptr; }
        endwin();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  BOOT ANIMATION
    //  Shows a splash screen with animated progress bar and boot messages.
    // ═══════════════════════════════════════════════════════════════════════════
    /*
     * boot()
     * Displays full-screen boot splash with:
     *   - ASCII art banner centered on screen
     *   - Hardware config summary
     *   - Animated progress bar advancing through boot stages
     * Called once at program start before the main menu loop.
     */
    void boot(const SystemConfig& cfg) {
        clear();

        int cy = rows_ / 2 - 8;
        int cx = cols_ / 2;

        // ── Banner ────────────────────────────────────────────────────────────
        attron(COLOR_PAIR(CP_CYAN) | A_BOLD);
        mvprintw(cy,   cx - 24, "╔══════════════════════════════════════════════╗");
        mvprintw(cy+1, cx - 24, "║         MINI  OS  SIMULATOR  v3.0            ║");
        mvprintw(cy+2, cx - 24, "║    Concurrent Railway Reservation System     ║");
        mvprintw(cy+3, cx - 24, "║          OS Lab Final Project – BONUS        ║");
        mvprintw(cy+4, cx - 24, "╚══════════════════════════════════════════════╝");
        attroff(COLOR_PAIR(CP_CYAN) | A_BOLD);

        // ── Hardware summary ──────────────────────────────────────────────────
        attron(COLOR_PAIR(CP_YELLOW));
        mvprintw(cy+6, cx - 20, "RAM: %lld MB   Cores: %d   Seats: %d",
                 cfg.totalRAM_MB, cfg.totalCores, cfg.totalSeats);
        attroff(COLOR_PAIR(CP_YELLOW));

        refresh();
        std::this_thread::sleep_for(std::chrono::milliseconds(600));

        // ── Boot stages with progress bar ─────────────────────────────────────
        const std::vector<std::string> stages = {
            "Initializing hardware...",
            "Loading kernel modules...",
            "Mounting file system...",
            "Starting IPC channels...",
            "Launching Railway service...",
            "Applying security policies...",
            "Boot complete!"
        };

        int barRow = cy + 9;
        int barW   = 44;
        int barX   = cx - 22;

        for (int s = 0; s < (int)stages.size(); s++) {
            // Stage label
            attron(COLOR_PAIR(CP_WHITE));
            mvprintw(barRow - 2, barX, "%-44s", stages[s].c_str());
            attroff(COLOR_PAIR(CP_WHITE));

            // Progress bar border
            attron(COLOR_PAIR(CP_CYAN));
            mvprintw(barRow, barX - 1, "[");
            mvprintw(barRow, barX + barW, "]");
            attroff(COLOR_PAIR(CP_CYAN));

            // Fill bar progressively
            int filled = (barW * (s + 1)) / (int)stages.size();
            attron(COLOR_PAIR(CP_GREEN) | A_REVERSE);
            for (int b = 0; b < filled; b++)
                mvprintw(barRow, barX + b, " ");
            attroff(COLOR_PAIR(CP_GREEN) | A_REVERSE);

            // Percentage
            attron(COLOR_PAIR(CP_YELLOW) | A_BOLD);
            int pct = (100 * (s + 1)) / (int)stages.size();
            mvprintw(barRow + 1, cx - 3, "%3d%%", pct);
            attroff(COLOR_PAIR(CP_YELLOW) | A_BOLD);

            refresh();
            std::this_thread::sleep_for(std::chrono::milliseconds(320));
        }

        // ── Success message ───────────────────────────────────────────────────
        attron(COLOR_PAIR(CP_GREEN) | A_BOLD);
        mvprintw(barRow + 3, cx - 14, "✓  System booted successfully!");
        attroff(COLOR_PAIR(CP_GREEN) | A_BOLD);
        refresh();
        std::this_thread::sleep_for(std::chrono::milliseconds(900));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  STATUS BAR  (permanent top strip)
    // ═══════════════════════════════════════════════════════════════════════════
    /*
     * drawStatusBar()
     * Draws a permanent 1-line status bar at row 0 showing:
     *   Mode (USER/KERNEL), scheduler algorithm, ready queue depth,
     *   RAM usage percentage, active core count.
     * Called at the start of every screen refresh.
     */
    void drawStatusBar(SystemMode mode, const std::string& algo,
                       int queueSz, long long usedRAM, long long totalRAM,
                       int usedCores, int totalCores) {
        if (statusWin_) { delwin(statusWin_); }
        statusWin_ = newwin(1, cols_, 0, 0);

        int cp = (mode == SystemMode::USER) ? CP_CYAN : CP_RED;
        wattron(statusWin_, COLOR_PAIR(cp) | A_BOLD | A_REVERSE);
        wprintw(statusWin_, " %-12s",
                mode == SystemMode::USER ? "[USER MODE]" : "[KERNEL MODE]");
        wattroff(statusWin_, COLOR_PAIR(cp) | A_BOLD | A_REVERSE);

        wattron(statusWin_, COLOR_PAIR(CP_YELLOW));
        wprintw(statusWin_, "  Algo:%-10s", algo.c_str());
        wattroff(statusWin_, COLOR_PAIR(CP_YELLOW));

        wattron(statusWin_, COLOR_PAIR(CP_WHITE));
        wprintw(statusWin_, "  Queue:%d", queueSz);
        int ramPct = (int)(usedRAM * 100 / (totalRAM ? totalRAM : 1));
        wprintw(statusWin_, "  RAM:%d%%", ramPct);
        wprintw(statusWin_, "  Cores:%d/%d", usedCores, totalCores);
        wprintw(statusWin_, "  F1=Help");
        wattroff(statusWin_, COLOR_PAIR(CP_WHITE));

        wrefresh(statusWin_);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  MAIN MENU
    //  Draws a bordered menu panel and returns the numeric choice entered.
    // ═══════════════════════════════════════════════════════════════════════════
    /*
     * menu()
     * title   : box title string
     * items   : vector of menu item strings
     * isKernel: true → red border, false → cyan border
     * Returns the integer entered by user (0–99), or -1 on invalid input.
     *
     * Renders:
     *   - Centered bordered box
     *   - Title in bold
     *   - Numbered items
     *   - Input prompt at bottom
     */
    int menu(const std::string& title,
             const std::vector<std::string>& items,
             bool isKernel = false) {
        clear();

        int menuH = (int)items.size() + 6;
        int menuW = 52;
        int startY = 2;   // below status bar
        int startX = (cols_ - menuW) / 2;
        if (startX < 0) startX = 0;

        WINDOW* win = newwin(menuH, menuW, startY, startX);
        int cp = isKernel ? CP_RED : CP_CYAN;

        wattron(win, COLOR_PAIR(cp) | A_BOLD);
        box(win, 0, 0);
        // Title centered
        int tx = (menuW - (int)title.size() - 2) / 2;
        mvwprintw(win, 0, tx, " %s ", title.c_str());
        wattroff(win, COLOR_PAIR(cp) | A_BOLD);

        // Items
        for (int i = 0; i < (int)items.size(); i++) {
            // Detect section dividers (start with ─)
            if (!items[i].empty() && items[i][0] == '\xe2') {
                wattron(win, COLOR_PAIR(CP_YELLOW) | A_BOLD);
                mvwprintw(win, i + 2, 2, "%-48s", items[i].c_str());
                wattroff(win, COLOR_PAIR(CP_YELLOW) | A_BOLD);
            } else {
                wattron(win, COLOR_PAIR(CP_WHITE));
                mvwprintw(win, i + 2, 2, "%-48s", items[i].c_str());
                wattroff(win, COLOR_PAIR(CP_WHITE));
            }
        }

        // Input prompt
        wattron(win, COLOR_PAIR(CP_YELLOW) | A_BOLD);
        mvwprintw(win, menuH - 2, 2, "Choice: ");
        wattroff(win, COLOR_PAIR(CP_YELLOW) | A_BOLD);

        wrefresh(win);

        // Read input (echo on for this)
        echo();
        curs_set(1);
        char buf[8] = {};
        mvwgetnstr(win, menuH - 2, 10, buf, 6);
        noecho();
        curs_set(0);

        delwin(win);

        try { return std::stoi(std::string(buf)); }
        catch (...) { return -1; }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  RESOURCE DASHBOARD
    //  Full-screen panel showing RAM bar, core grid, seat map side by side.
    // ═══════════════════════════════════════════════════════════════════════════
    /*
     * drawDashboard()
     * Renders a two-column dashboard:
     *   Left  : RAM usage bar graph, disk info, core availability grid
     *   Right : Seat map (colored squares — green=free, red=booked)
     * Waits for any key before returning.
     */
    void drawDashboard(const SystemConfig& cfg,
                       const std::vector<Seat>& seats) {
        clear();

        int startY = 2;

        // ── Left panel: Resources ─────────────────────────────────────────────
        WINDOW* leftWin = newwin(rows_ - 3, cols_ / 2 - 1, startY, 0);
        wattron(leftWin, COLOR_PAIR(CP_CYAN) | A_BOLD);
        box(leftWin, 0, 0);
        mvwprintw(leftWin, 0, 2, " Resource Monitor ");
        wattroff(leftWin, COLOR_PAIR(CP_CYAN) | A_BOLD);

        // RAM bar
        int barW = cols_ / 2 - 8;
        long long freeRAM = cfg.totalRAM_MB - cfg.usedRAM_MB;
        int ramPct = (int)(cfg.usedRAM_MB * 100 / (cfg.totalRAM_MB ? cfg.totalRAM_MB : 1));
        int filled = barW * ramPct / 100;

        wattron(leftWin, COLOR_PAIR(CP_WHITE) | A_BOLD);
        mvwprintw(leftWin, 2, 2, "RAM Usage: %lld / %lld MB (%d%%)",
                  cfg.usedRAM_MB, cfg.totalRAM_MB, ramPct);
        wattroff(leftWin, COLOR_PAIR(CP_WHITE) | A_BOLD);

        mvwprintw(leftWin, 3, 2, "[");
        mvwprintw(leftWin, 3, 3 + barW, "]");
        // Filled portion
        int fillColor = ramPct > 80 ? CP_RED : (ramPct > 50 ? CP_YELLOW : CP_GREEN);
        wattron(leftWin, COLOR_PAIR(fillColor) | A_REVERSE);
        for (int b = 0; b < filled; b++)
            mvwprintw(leftWin, 3, 3 + b, " ");
        wattroff(leftWin, COLOR_PAIR(fillColor) | A_REVERSE);
        // Empty portion
        wattron(leftWin, COLOR_PAIR(CP_WHITE));
        for (int b = filled; b < barW; b++)
            mvwprintw(leftWin, 3, 3 + b, "░");
        wattroff(leftWin, COLOR_PAIR(CP_WHITE));

        // Free RAM
        wattron(leftWin, COLOR_PAIR(CP_GREEN));
        mvwprintw(leftWin, 4, 2, "Free: %lld MB", freeRAM);
        wattroff(leftWin, COLOR_PAIR(CP_GREEN));

        // Disk
        wattron(leftWin, COLOR_PAIR(CP_WHITE) | A_BOLD);
        mvwprintw(leftWin, 6, 2, "Disk: %lld GB total", cfg.totalDisk_GB);
        attroff(A_BOLD);

        // CPU Cores grid
        wattron(leftWin, COLOR_PAIR(CP_WHITE) | A_BOLD);
        mvwprintw(leftWin, 8, 2, "CPU Cores: %d / %d in use",
                  cfg.usedCores, cfg.totalCores);
        wattroff(leftWin, COLOR_PAIR(CP_WHITE) | A_BOLD);

        // Draw core squares: ■ = used, □ = free
        for (int c = 0; c < cfg.totalCores; c++) {
            int crow = 9 + c / 8;
            int ccol = 2 + (c % 8) * 4;
            if (c < cfg.usedCores) {
                wattron(leftWin, COLOR_PAIR(CP_RED));
                mvwprintw(leftWin, crow, ccol, "[■]");
                wattroff(leftWin, COLOR_PAIR(CP_RED));
            } else {
                wattron(leftWin, COLOR_PAIR(CP_GREEN));
                mvwprintw(leftWin, crow, ccol, "[□]");
                wattroff(leftWin, COLOR_PAIR(CP_GREEN));
            }
        }

        // Legend
        wattron(leftWin, COLOR_PAIR(CP_GREEN));
        mvwprintw(leftWin, 11, 2, "[□]=Free  ");
        wattroff(leftWin, COLOR_PAIR(CP_GREEN));
        wattron(leftWin, COLOR_PAIR(CP_RED));
        mvwprintw(leftWin, 11, 12, "[■]=Used");
        wattroff(leftWin, COLOR_PAIR(CP_RED));

        wrefresh(leftWin);

        // ── Right panel: Seat Map ─────────────────────────────────────────────
        WINDOW* rightWin = newwin(rows_ - 3, cols_ / 2, startY, cols_ / 2);
        wattron(rightWin, COLOR_PAIR(CP_CYAN) | A_BOLD);
        box(rightWin, 0, 0);
        mvwprintw(rightWin, 0, 2, " Seat Map ");
        wattroff(rightWin, COLOR_PAIR(CP_CYAN) | A_BOLD);

        int free = 0, booked = 0;
        for (int i = 0; i < (int)seats.size(); i++) {
            int row = 2 + i / 5;
            int col = 2 + (i % 5) * 8;
            if (seats[i].booked) {
                wattron(rightWin, COLOR_PAIR(CP_RED) | A_BOLD);
                mvwprintw(rightWin, row, col, "[%2d]", seats[i].number);
                wattroff(rightWin, COLOR_PAIR(CP_RED) | A_BOLD);
                booked++;
            } else {
                wattron(rightWin, COLOR_PAIR(CP_GREEN));
                mvwprintw(rightWin, row, col, "[%2d]", seats[i].number);
                wattroff(rightWin, COLOR_PAIR(CP_GREEN));
                free++;
            }
        }

        // Summary
        int sumRow = 2 + ((int)seats.size() + 4) / 5 + 1;
        wattron(rightWin, COLOR_PAIR(CP_GREEN));
        mvwprintw(rightWin, sumRow,     2, "Free   : %d", free);
        wattroff(rightWin, COLOR_PAIR(CP_GREEN));
        wattron(rightWin, COLOR_PAIR(CP_RED));
        mvwprintw(rightWin, sumRow + 1, 2, "Booked : %d", booked);
        wattroff(rightWin, COLOR_PAIR(CP_RED));
        wattron(rightWin, COLOR_PAIR(CP_WHITE));
        mvwprintw(rightWin, sumRow + 2, 2, "Total  : %d", (int)seats.size());
        wattroff(rightWin, COLOR_PAIR(CP_WHITE));

        // Legend
        wattron(rightWin, COLOR_PAIR(CP_GREEN));
        mvwprintw(rightWin, sumRow + 4, 2, "[ ##]=Free   ");
        wattroff(rightWin, COLOR_PAIR(CP_GREEN));
        wattron(rightWin, COLOR_PAIR(CP_RED));
        mvwprintw(rightWin, sumRow + 4, 15, "[ ##]=Booked");
        wattroff(rightWin, COLOR_PAIR(CP_RED));

        wrefresh(rightWin);

        // Wait for keypress
        waitKey(leftWin);
        delwin(leftWin);
        delwin(rightWin);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  PROCESS TABLE
    //  Draws all PCBs color-coded by state in a bordered window.
    // ═══════════════════════════════════════════════════════════════════════════
    /*
     * drawProcessTable()
     * Renders a scrollable (static for simplicity) process table.
     * Each row is colored by process state:
     *   NEW=white, READY=cyan, RUNNING=green bold, BLOCKED=yellow, TERMINATED=dim
     */
    void drawProcessTable(const std::vector<PCB>& procs,
                          const SystemConfig& cfg) {
        clear();

        int winH = rows_ - 3;
        int winW = cols_;
        WINDOW* win = newwin(winH, winW, 2, 0);

        wattron(win, COLOR_PAIR(CP_CYAN) | A_BOLD);
        box(win, 0, 0);
        mvwprintw(win, 0, 2, " Process Table ");
        wattroff(win, COLOR_PAIR(CP_CYAN) | A_BOLD);

        // Header
        wattron(win, COLOR_PAIR(CP_YELLOW) | A_BOLD | A_UNDERLINE);
        mvwprintw(win, 1, 2, "%-5s %-18s %-8s %-5s %-6s %-11s",
                  "PID", "Name", "Action", "Pri", "Mem", "State");
        wattroff(win, COLOR_PAIR(CP_YELLOW) | A_BOLD | A_UNDERLINE);

        for (int i = 0; i < (int)procs.size() && i < winH - 5; i++) {
            const auto& p = procs[i];
            int cp;
            attr_t attr = A_NORMAL;
            switch (p.state) {
                case ProcessState::NEW:        cp = CP_WHITE;   break;
                case ProcessState::READY:      cp = CP_CYAN;    break;
                case ProcessState::RUNNING:    cp = CP_GREEN; attr = A_BOLD; break;
                case ProcessState::BLOCKED:    cp = CP_YELLOW;  break;
                case ProcessState::TERMINATED: cp = CP_WHITE; attr = A_DIM;  break;
                default:                       cp = CP_WHITE;
            }
            wattron(win, COLOR_PAIR(cp) | attr);
            mvwprintw(win, i + 2, 2, "%-5d %-18s %-8s %-5d %-6d %-11s",
                      p.pid, p.name.c_str(), p.action.c_str(),
                      p.priority, p.memoryMB, stateStr(p.state).c_str());
            wattroff(win, COLOR_PAIR(cp) | attr);
        }

        // Resource footer
        wattron(win, COLOR_PAIR(CP_YELLOW));
        mvwprintw(win, winH - 3, 2,
                  "RAM: %lld/%lld MB   Cores: %d/%d   Disk: %lld GB",
                  cfg.usedRAM_MB, cfg.totalRAM_MB,
                  cfg.usedCores, cfg.totalCores, cfg.totalDisk_GB);
        wattroff(win, COLOR_PAIR(CP_YELLOW));

        // State color legend
        wattron(win, COLOR_PAIR(CP_WHITE));   mvwprintw(win, winH-2, 2,  "NEW ");    wattroff(win, COLOR_PAIR(CP_WHITE));
        wattron(win, COLOR_PAIR(CP_CYAN));    mvwprintw(win, winH-2, 6,  "READY ");  wattroff(win, COLOR_PAIR(CP_CYAN));
        wattron(win, COLOR_PAIR(CP_GREEN) | A_BOLD); mvwprintw(win, winH-2, 12, "RUNNING "); wattroff(win, COLOR_PAIR(CP_GREEN) | A_BOLD);
        wattron(win, COLOR_PAIR(CP_YELLOW)); mvwprintw(win, winH-2, 20, "BLOCKED "); wattroff(win, COLOR_PAIR(CP_YELLOW));
        wattron(win, COLOR_PAIR(CP_WHITE) | A_DIM); mvwprintw(win, winH-2, 28, "TERMINATED"); wattroff(win, COLOR_PAIR(CP_WHITE) | A_DIM);

        wrefresh(win);
        waitKey(win);
        delwin(win);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  INPUT DIALOG
    //  Shows a small centered dialog box and reads a string from the user.
    // ═══════════════════════════════════════════════════════════════════════════
    /*
     * inputDialog()
     * prompt : label shown inside the box
     * Returns the string typed by the user.
     */
    std::string inputDialog(const std::string& title,
                            const std::string& prompt) {
        int dh = 6, dw = 54;
        int dy = rows_ / 2 - 3;
        int dx = (cols_ - dw) / 2;

        WINDOW* win = newwin(dh, dw, dy, dx);
        wattron(win, COLOR_PAIR(CP_YELLOW) | A_BOLD);
        box(win, 0, 0);
        mvwprintw(win, 0, 2, " %s ", title.c_str());
        wattroff(win, COLOR_PAIR(CP_YELLOW) | A_BOLD);

        wattron(win, COLOR_PAIR(CP_WHITE));
        mvwprintw(win, 2, 2, "%s", prompt.c_str());
        wattroff(win, COLOR_PAIR(CP_WHITE));

        wattron(win, COLOR_PAIR(CP_CYAN));
        mvwprintw(win, 3, 2, "> ");
        wattroff(win, COLOR_PAIR(CP_CYAN));

        wrefresh(win);

        echo();
        curs_set(1);
        char buf[128] = {};
        mvwgetnstr(win, 3, 4, buf, 120);
        noecho();
        curs_set(0);

        delwin(win);
        return std::string(buf);
    }

    /*
     * inputInt()
     * Convenience wrapper around inputDialog() that returns an integer.
     */
    int inputInt(const std::string& title, const std::string& prompt) {
        std::string s = inputDialog(title, prompt);
        try { return std::stoi(s); } catch (...) { return -1; }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  MESSAGE / RESULT BOX
    //  Shows a transient colored message box; auto-dismiss after timeout or key.
    // ═══════════════════════════════════════════════════════════════════════════
    /*
     * msgBox()
     * success : true=green border, false=red border
     * lines   : message lines to display
     * waitMs  : auto-dismiss after this many ms (0 = wait for key)
     */
    void msgBox(bool success,
                const std::vector<std::string>& lines,
                int waitMs = 0) {
        int dw = 56;
        int dh = (int)lines.size() + 4;
        int dy = rows_ / 2 - dh / 2;
        int dx = (cols_ - dw) / 2;

        WINDOW* win = newwin(dh, dw, dy, dx);
        int cp = success ? CP_GREEN : CP_RED;
        wattron(win, COLOR_PAIR(cp) | A_BOLD);
        box(win, 0, 0);
        mvwprintw(win, 0, 2, success ? " SUCCESS " : " ERROR ");
        wattroff(win, COLOR_PAIR(cp) | A_BOLD);

        for (int i = 0; i < (int)lines.size(); i++) {
            wattron(win, COLOR_PAIR(CP_WHITE));
            mvwprintw(win, i + 2, 2, "%s", lines[i].c_str());
            wattroff(win, COLOR_PAIR(CP_WHITE));
        }

        if (waitMs == 0) {
            wattron(win, COLOR_PAIR(CP_YELLOW));
            mvwprintw(win, dh - 1, 2, " Press any key... ");
            wattroff(win, COLOR_PAIR(CP_YELLOW));
        }

        wrefresh(win);

        if (waitMs > 0)
            std::this_thread::sleep_for(std::chrono::milliseconds(waitMs));
        else
            wgetch(win);

        delwin(win);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  BANKER'S ALGORITHM VISUALIZER
    //  Displays the Allocation/Max/Need table and safe-sequence result.
    // ═══════════════════════════════════════════════════════════════════════════
    /*
     * drawBankerState()
     * Renders the Banker's Algorithm state as a colored table:
     *   - Each row = one process
     *   - Columns: Allocation, Max, Need for each resource
     *   - Available vector shown at bottom
     *   - Safe sequence (if any) shown highlighted
     */
    void drawBankerState(const std::vector<BankersAlgorithm::GUIRow>& rows,
                         const std::vector<long long>& avail,
                         bool isSafe,
                         const std::string& safeSeq) {
        clear();
        int winH = rows_ - 3;
        WINDOW* win = newwin(winH, cols_, 2, 0);

        wattron(win, COLOR_PAIR(CP_MAGENTA) | A_BOLD);
        box(win, 0, 0);
        mvwprintw(win, 0, 2, " Banker's Algorithm – State Visualizer ");
        wattroff(win, COLOR_PAIR(CP_MAGENTA) | A_BOLD);

        // Resource names header
        wattron(win, COLOR_PAIR(CP_YELLOW) | A_BOLD | A_UNDERLINE);
        mvwprintw(win, 1, 2,
            "%-4s %-10s | Alloc[R M C] | Max[R M C]   | Need[R M C]",
            "PID", "Name");
        wattroff(win, COLOR_PAIR(CP_YELLOW) | A_BOLD | A_UNDERLINE);

        for (int i = 0; i < (int)rows.size() && i < winH - 7; i++) {
            const auto& r = rows[i];
            int cp = r.finished ? CP_WHITE : CP_CYAN;
            attr_t at = r.finished ? A_DIM : A_NORMAL;
            wattron(win, COLOR_PAIR(cp) | at);
            mvwprintw(win, i + 2, 2,
                "%-4d %-10s | %5lld%5lld%5lld | %5lld%5lld%5lld | %5lld%5lld%5lld",
                r.pid, r.name.c_str(),
                r.alloc.size()>0?r.alloc[0]:0LL, r.alloc.size()>1?r.alloc[1]:0LL, r.alloc.size()>2?r.alloc[2]:0LL,
                r.max.size()>0?r.max[0]:0LL,     r.max.size()>1?r.max[1]:0LL,     r.max.size()>2?r.max[2]:0LL,
                r.need.size()>0?r.need[0]:0LL,   r.need.size()>1?r.need[1]:0LL,   r.need.size()>2?r.need[2]:0LL);
            wattroff(win, COLOR_PAIR(cp) | at);
        }

        // Available vector
        int baseRow = (int)rows.size() + 3;
        wattron(win, COLOR_PAIR(CP_WHITE) | A_BOLD);
        mvwprintw(win, baseRow, 2,
            "Available: RAM=%lld  Cores=%lld  Seats=%lld",
            avail.size() > 0 ? avail[0] : 0,
            avail.size() > 1 ? avail[1] : 0,
            avail.size() > 2 ? avail[2] : 0);
        wattroff(win, COLOR_PAIR(CP_WHITE) | A_BOLD);

        // Safety result
        if (isSafe) {
            wattron(win, COLOR_PAIR(CP_GREEN) | A_BOLD);
            mvwprintw(win, baseRow + 2, 2, "✓ SAFE STATE");
            wattroff(win, COLOR_PAIR(CP_GREEN) | A_BOLD);
            wattron(win, COLOR_PAIR(CP_WHITE));
            mvwprintw(win, baseRow + 3, 2, "Safe sequence: %s", safeSeq.c_str());
            wattroff(win, COLOR_PAIR(CP_WHITE));
        } else {
            wattron(win, COLOR_PAIR(CP_RED) | A_BOLD);
            mvwprintw(win, baseRow + 2, 2, "✗ UNSAFE STATE – deadlock risk!");
            wattroff(win, COLOR_PAIR(CP_RED) | A_BOLD);
        }

        wrefresh(win);
        waitKey(win);
        delwin(win);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  HELP SCREEN
    // ═══════════════════════════════════════════════════════════════════════════
    void drawHelp() {
        clear();
        WINDOW* win = newwin(rows_ - 2, cols_, 2, 0);
        wattron(win, COLOR_PAIR(CP_CYAN) | A_BOLD);
        box(win, 0, 0);
        mvwprintw(win, 0, 2, " Mini OS Simulator – Help ");
        wattroff(win, COLOR_PAIR(CP_CYAN) | A_BOLD);

        const std::vector<std::pair<std::string,std::string>> help = {
            {"USER MODE",        "Passenger-facing Railway interface"},
            {"KERNEL MODE",      "Admin access (password: kernel123)"},
            {"Book Ticket",      "Creates a new process, dispatches it via scheduler"},
            {"Concurrent Demo",  "Spawns N threads simultaneously – shows mutex/sem"},
            {"Multitask Demo",   "Queues 4 processes, dispatches by current algo"},
            {"Change Algo",      "Switch between FCFS / Round Robin / Priority"},
            {"Banker's Algo",    "Deadlock avoidance – checks safe state before grant"},
            {"Deadlock Prev",    "Resource ordering – prevents circular wait"},
            {"Interrupt",        "Raises TICKET_CANCEL / TIMEOUT / SHUTDOWN"},
            {"IPC Pipe/Queue",   "Inter-process communication channel demo"},
            {"Dashboard",        "Real-time RAM bar, core grid, seat map"},
        };

        for (int i = 0; i < (int)help.size(); i++) {
            wattron(win, COLOR_PAIR(CP_YELLOW) | A_BOLD);
            mvwprintw(win, i + 2, 2, "%-20s", help[i].first.c_str());
            wattroff(win, COLOR_PAIR(CP_YELLOW) | A_BOLD);
            wattron(win, COLOR_PAIR(CP_WHITE));
            mvwprintw(win, i + 2, 22, "%s", help[i].second.c_str());
            wattroff(win, COLOR_PAIR(CP_WHITE));
        }

        wattron(win, COLOR_PAIR(CP_CYAN));
        mvwprintw(win, rows_ - 4, 2, "Press any key to return...");
        wattroff(win, COLOR_PAIR(CP_CYAN));
        wrefresh(win);
        wgetch(win);
        delwin(win);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  SHUTDOWN ANIMATION
    // ═══════════════════════════════════════════════════════════════════════════
    /*
     * shutdownAnim()
     * Shows a centered "SYSTEM HALTED" message with a brief animation.
     */
    void shutdownAnim() {
        clear();
        int cy = rows_ / 2;
        int cx = cols_ / 2;

        attron(COLOR_PAIR(CP_YELLOW) | A_BOLD);
        mvprintw(cy - 2, cx - 18, "╔════════════════════════════════════╗");
        mvprintw(cy - 1, cx - 18, "║       Flushing data to disk...     ║");
        mvprintw(cy,     cx - 18, "║       All data saved safely.       ║");
        mvprintw(cy + 1, cx - 18, "║          SYSTEM  HALTED            ║");
        mvprintw(cy + 2, cx - 18, "╚════════════════════════════════════╝");
        attroff(COLOR_PAIR(CP_YELLOW) | A_BOLD);
        refresh();
        std::this_thread::sleep_for(std::chrono::milliseconds(1500));
    }

    int rows() const { return rows_; }
    int cols() const { return cols_; }

private:
    // ── Wait for any key, show prompt ─────────────────────────────────────────
    void waitKey(WINDOW* win) {
        int r, c;
        getmaxyx(win, r, c);
        wattron(win, COLOR_PAIR(CP_YELLOW));
        mvwprintw(win, r - 1, 2, " Press any key to continue... ");
        wattroff(win, COLOR_PAIR(CP_YELLOW));
        wrefresh(win);
        wgetch(win);
    }

    WINDOW* statusWin_;
    int     rows_, cols_;
};
