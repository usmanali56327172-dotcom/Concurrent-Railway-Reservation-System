/*
 * main.cpp
 * ─────────────────────────────────────────────────────────────────────────────
 * Mini OS Simulator – Entry Point
 * Instantiates all OS subsystems, runs the boot sequence, and
 * drives the main event loop until system shutdown.
 *
 * File structure (why 4 files, not 8):
 *   os_core.h        – shared types, PCB, Seat, SystemConfig, Logger
 *   os_subsystems.h  – ResourceManager, ProcessManager, Scheduler, IPC, Interrupts
 *   railway.h        – Concurrent Railway Reservation System
 *   main.cpp         – Boot, menus, user/kernel mode, main loop (this file)
 *
 * Compile: g++ -std=c++17 -pthread -O2 -o os_sim main.cpp
 * Run:     ./os_sim
 * ─────────────────────────────────────────────────────────────────────────────
 */

#include "os_core.h"
#include "os_subsystems.h"
#include "railway.h"
#include "banker.h"
#include <thread>
#include <chrono>
#include <limits>
#include <sys/stat.h>   // mkdir

// ─────────────────────────────────────────────────────────────────────────────
//  MINI OS CLASS
// ─────────────────────────────────────────────────────────────────────────────
class MiniOS {
public:
    MiniOS()
        : rm_(cfg_),
          pm_(),
          scheduler_(pm_, rm_, cfg_),
          ipc_(),
          intHandler_(pm_),
          railway_(std::make_unique<RailwaySystem>(20, ipc_)),
          banker_(std::make_unique<BankersAlgorithm>(
              std::vector<long long>{2048, 8, 20})),   // RAM, Cores, Seats
          mode_(SystemMode::USER),
          running_(false) {}

    // ── Boot Sequence ──────────────────────────────────────────────────────────
    void boot() {
        // Ensure data/ directory exists before Logger or Railway try to write files
        mkdir("data", 0755);

        clear();
        banner();

        std::cout << "\033[33m  [BOOT] Initializing hardware...\033[0m\n";
        configureHardware();

        dot("  [BOOT] Loading kernel");
        dot("  [BOOT] Mounting file system");
        dot("  [BOOT] Starting IPC channels");
        dot("  [BOOT] Starting Railway service");

        Logger::get().init("data/system_log.txt");

        std::cout << "\n\033[32m  ✓ Mini OS booted successfully!\033[0m\n\n";
        LOG("OS: Boot complete | RAM=" + std::to_string(cfg_.totalRAM_MB)
            + "MB | Cores=" + std::to_string(cfg_.totalCores)
            + " | Seats=" + std::to_string(cfg_.totalSeats));

        std::this_thread::sleep_for(std::chrono::milliseconds(700));
        running_ = true;
    }

    // ── Main Event Loop ────────────────────────────────────────────────────────
    void run() {
        while (running_) {
            clear();
            statusBar();
            if (mode_ == SystemMode::USER)
                userMenu();
            else
                kernelMenu();

            if (intHandler_.shuttingDown()) {
                shutdown();
                return;
            }
        }
    }

private:
    // ══════════════════════════════════════════════════════════════════════════
    //  USER MODE MENU
    // ══════════════════════════════════════════════════════════════════════════
    void userMenu() {
        std::cout << "\n\033[36m  ╔══════════════════════════════════════╗\033[0m\n";
        std::cout << "\033[36m  ║   Railway Reservation System          ║\033[0m\n";
        std::cout << "\033[36m  ╚══════════════════════════════════════╝\033[0m\n";
        std::cout << "  1.  Book Ticket\n";
        std::cout << "  2.  Cancel Ticket\n";
        std::cout << "  3.  View Available Seats\n";
        std::cout << "  4.  View All Bookings\n";
        std::cout << "  5.  Passenger Info Lookup\n";
        std::cout << "  6.  Concurrent Booking Demo\n";
        std::cout << "  7.  Multitasking Demo (Multiple Processes)\n";
        std::cout << "  8.  Process Table & Resources\n";
        std::cout << "  9.  IPC Message Queue\n";
        std::cout << "  10. Change Scheduling Algorithm\n";
        std::cout << "  11. Switch to Kernel Mode\n";
        std::cout << "  0.  Exit\n";
        std::cout << "\n  Choice: ";

        switch (readInt()) {
            case 1:  doBook();                                        break;
            case 2:  doCancel();                                      break;
            case 3:  railway_->viewAvailable();   pause();             break;
            case 4:  railway_->viewBookings();    pause();             break;
            case 5:  doPassengerLookup();                             break;
            case 6:  railway_->concurrentDemo(pm_, 6); pause();       break;
            case 7:  doMultitaskingDemo();                            break;
            case 8:  pm_.printTable(); rm_.printStatus(); pause();    break;
            case 9:  ipc_.printMessageQueue();   pause();             break;
            case 10: changeAlgo();                                    break;
            case 11: enterKernel();                                   break;
            case 0:  intHandler_.raise(InterruptType::SYSTEM_SHUTDOWN); break;
            default: std::cout << "\033[31m  Invalid option.\033[0m\n"; pause();
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  KERNEL MODE MENU
    // ══════════════════════════════════════════════════════════════════════════
    void kernelMenu() {
        std::cout << "\n\033[31m  ╔══════════════════════════════════════╗\033[0m\n";
        std::cout << "\033[31m  ║   KERNEL MODE                         ║\033[0m\n";
        std::cout << "\033[31m  ╚══════════════════════════════════════╝\033[0m\n";
        std::cout << "  1.  View Process Table\n";
        std::cout << "  2.  Force-Terminate Process\n";
        std::cout << "  3.  View Resource Usage\n";
        std::cout << "  4.  Reset Seat Database\n";
        std::cout << "  5.  Raise Interrupt\n";
        std::cout << "  6.  Recover Blocked Processes -> READY\n";
        std::cout << "  7.  View IPC Message Queue\n";
        std::cout << "  8.  Write to IPC Pipe\n";
        std::cout << "  9.  Read IPC Pipe\n";
        std::cout << "  10. System Shutdown\n";
        std::cout << "  11. Return to User Mode\n";
        std::cout << "\033[33m  ── BONUS ──────────────────────────────\033[0m\n";
        std::cout << "  12. Banker's Algorithm – Safety Check\n";
        std::cout << "  13. Banker's Algorithm – Register Process\n";
        std::cout << "  14. Banker's Algorithm – Resource Request\n";
        std::cout << "  15. Banker's Algorithm – Full Demo\n";
        std::cout << "  16. Deadlock Prevention – Explanation\n";
        std::cout << "  17. Deadlock Prevention – Demo\n";
        std::cout << "\n  Choice: ";

        switch (readInt()) {
            case 1:  pm_.printTable();            pause();  break;
            case 2:  doKernelTerminate();                   break;
            case 3:  rm_.printStatus();           pause();  break;
            case 4:  railway_->resetAll();         pause();  break;
            case 5:  doRaiseInterrupt();                    break;
            case 6:  intHandler_.unblockProcesses(); pause(); break;
            case 7:  ipc_.printMessageQueue();    pause();  break;
            case 8:  doIPCWrite();                          break;
            case 9:  doIPCRead();                           break;
            case 10: intHandler_.raise(InterruptType::SYSTEM_SHUTDOWN); break;
            case 11: mode_ = SystemMode::USER;
                     LOG("OS: -> USER mode");               break;
            // ── BONUS ──────────────────────────────────────────────────────
            case 12: banker_->checkSafety();       pause();  break;
            case 13: doBankerRegister();                     break;
            case 14: doBankerRequest();                      break;
            case 15: banker_->runDemo({cfg_.totalRAM_MB, cfg_.totalCores, cfg_.totalSeats});
                     pause();                               break;
            case 16: DeadlockPrevention::printExplanation(); pause(); break;
            case 17: DeadlockPrevention::runDemo();  pause(); break;
            default: std::cout << "\033[31m  Invalid option.\033[0m\n"; pause();
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  USER ACTIONS
    // ══════════════════════════════════════════════════════════════════════════

    void doBook() {
        std::string name, id;
        int seat;
        std::cout << "  Passenger Name : "; std::getline(std::cin, name);
        std::cout << "  Passenger ID   : "; std::getline(std::cin, id);
        std::cout << "  Seat No (1-" << railway_->totalSeats() << "): ";
        seat = readInt();

        // Each booking request = a new process (simulates multitasking)
        int pid = pm_.createProcess(name, "BOOK", 64, 100, 1);
        PCB* p  = pm_.get(pid);
        if (p) { p->passengerName = name; p->seatRequested = seat; }
        pm_.makeReady(pid);

        // Scheduler dispatches the process; the lambda IS the process logic
        scheduler_.dispatch([&](PCB& pcb) {
            railway_->bookTicket(seat, name, id, pcb.pid);
        });
        pause();
    }

    void doCancel() {
        int seat;
        std::cout << "  Seat No to cancel: "; seat = readInt();

        int pid = pm_.createProcess("CancelReq", "CANCEL", 32, 50, 2);
        pm_.makeReady(pid);

        // Raise the cancellation interrupt before dispatching
        intHandler_.raise(InterruptType::TICKET_CANCEL);

        scheduler_.dispatch([&](PCB& pcb) {
            intHandler_.handle(pcb.pid);        // handle interrupt first
            railway_->cancelTicket(seat, pcb.pid);
        });
        pause();
    }

    void doPassengerLookup() {
        std::string query;
        std::cout << "  Enter name or ID to search: "; std::getline(std::cin, query);
        railway_->passengerInfo(query);
        pause();
    }

    /*
     * doMultitaskingDemo()
     * ─────────────────────────────────────────────────────────────────────────
     * Demonstrates true OS multitasking:
     *   - Creates N processes simultaneously (each with its own PCB)
     *   - Each process has a different action: BOOK, VIEW, INFO
     *   - All enter the Ready Queue; scheduler dispatches them one by one
     *   - Process table is printed to show state transitions live
     * This proves the OS can manage multiple concurrent user tasks.
     */
    void doMultitaskingDemo() {
        std::cout << "\n\033[36m  ════════════════════════════════════════\033[0m\n";
        std::cout << "\033[36m  MULTITASKING DEMO – OS Process Simulation\033[0m\n";
        std::cout << "\033[36m  ════════════════════════════════════════\033[0m\n";
        std::cout << "  Spawning 4 processes with mixed actions...\n\n";
        LOG("MULTITASK DEMO: Starting");

        // Process 1 – Book seat 1
        int p1 = pm_.createProcess("Alice",   "BOOK",   64,  120, 2);
        // Process 2 – View available seats
        int p2 = pm_.createProcess("Bob",     "VIEW",   32,   60, 3);
        // Process 3 – Book seat 2
        int p3 = pm_.createProcess("Charlie", "BOOK",   64,  120, 1);
        // Process 4 – Passenger info lookup
        int p4 = pm_.createProcess("Diana",   "INFO",   32,   80, 2);

        // All 4 enter Ready Queue simultaneously (simulates multitasking)
        pm_.makeReady(p1);
        pm_.makeReady(p2);
        pm_.makeReady(p3);
        pm_.makeReady(p4);

        std::cout << "  [QUEUE] 4 processes now in Ready Queue.\n";
        std::cout << "  [SCHEDULER] Dispatching with algo: "
                  << scheduler_.algoName() << "\n\n";

        // Dispatch all 4 – each runs its task, shows state transitions
        scheduler_.dispatch([&](PCB& pcb) {
            std::cout << "  [PID=" << pcb.pid << "] Alice -> booking seat 1\n";
            railway_->bookTicket(1, "Alice", "A001", pcb.pid);
        });
        scheduler_.dispatch([&](PCB& pcb) {
            std::cout << "  [PID=" << pcb.pid << "] Bob -> viewing seats\n";
            railway_->viewAvailable();
        });
        scheduler_.dispatch([&](PCB& pcb) {
            std::cout << "  [PID=" << pcb.pid << "] Charlie -> booking seat 2\n";
            railway_->bookTicket(2, "Charlie", "C002", pcb.pid);
        });
        scheduler_.dispatch([&](PCB& pcb) {
            std::cout << "  [PID=" << pcb.pid << "] Diana -> info lookup\n";
            railway_->passengerInfo("Alice");
        });

        std::cout << "\n\033[32m  All processes completed. Final process table:\033[0m\n";
        pm_.printTable();
        rm_.printStatus();
        LOG("MULTITASK DEMO: Complete");
        pause();
    }

    void changeAlgo() {
        std::cout << "  1. FCFS   2. Round Robin   3. Priority\n  Choice: ";
        switch (readInt()) {
            case 1: scheduler_.setAlgo(SchedulingAlgo::FCFS);        break;
            case 2: scheduler_.setAlgo(SchedulingAlgo::ROUND_ROBIN); break;
            case 3: scheduler_.setAlgo(SchedulingAlgo::PRIORITY);    break;
            default: std::cout << "\033[31m  Invalid.\033[0m\n";
        }
        pause();
    }

    void enterKernel() {
        std::string pw;
        std::cout << "  Kernel password: "; std::getline(std::cin, pw);
        if (pw == "kernel123") {
            mode_ = SystemMode::KERNEL;
            LOG("OS: -> KERNEL mode");
        } else {
            std::cout << "\033[31m  Access denied.\033[0m\n";
            pause();
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  KERNEL ACTIONS
    // ══════════════════════════════════════════════════════════════════════════

    void doKernelTerminate() {
        std::cout << "  PID to terminate: ";
        int pid = readInt();
        if (pm_.forceTerminate(pid))
            std::cout << "\033[32m  PID " << pid << " terminated.\033[0m\n";
        else
            std::cout << "\033[31m  Not found or already terminated.\033[0m\n";
        pause();
    }

    void doRaiseInterrupt() {
        std::cout << "  1. TICKET_CANCEL  2. BOOKING_TIMEOUT  3. SYSTEM_SHUTDOWN\n  Choice: ";
        switch (readInt()) {
            case 1: intHandler_.raise(InterruptType::TICKET_CANCEL);   break;
            case 2: intHandler_.raise(InterruptType::BOOKING_TIMEOUT); break;
            case 3: intHandler_.raise(InterruptType::SYSTEM_SHUTDOWN); break;
            default: std::cout << "\033[31m  Invalid.\033[0m\n";
        }
        pause();
    }

    void doIPCWrite() {
        std::string msg;
        std::cout << "  PID sending: ";  int from = readInt();
        std::cout << "  Message: ";      std::getline(std::cin, msg);
        ipc_.pipeWrite(from, msg);
        std::cout << "\033[32m  Written to pipe.\033[0m\n";
        pause();
    }

    void doIPCRead() {
        std::cout << "  PID reading: "; int pid = readInt();
        std::string data = ipc_.pipeRead(pid);
        std::cout << "  Pipe contents:\n  " << data << "\n";
        pause();
    }

    // ── BONUS: Banker's Algorithm interactive functions ────────────────────────

    /*
     * doBankerRegister()
     * Kernel admin registers a new process with Banker's Algorithm.
     * Admin enters PID, name, and the maximum claim for each resource type.
     * This simulates a process declaring its resource needs at creation time.
     */
    void doBankerRegister() {
        std::cout << "\n  Register process with Banker's Algorithm\n";
        std::cout << "  Resources: 0=RAM(MB)  1=Cores  2=Seats\n\n";
        std::cout << "  PID   : "; int pid = readInt();
        std::string name;
        std::cout << "  Name  : "; std::getline(std::cin, name);
        std::vector<long long> maxClaim(NUM_RESOURCES);
        std::cout << "  Max RAM needed (MB)   : "; maxClaim[0] = readInt();
        std::cout << "  Max Cores needed      : "; maxClaim[1] = readInt();
        std::cout << "  Max Seats needed      : "; maxClaim[2] = readInt();

        // Validate: max claim cannot exceed system total
        std::vector<long long> totals = {cfg_.totalRAM_MB, cfg_.totalCores, cfg_.totalSeats};
        bool valid = true;
        for (int r = 0; r < NUM_RESOURCES; r++) {
            if (maxClaim[r] < 0 || maxClaim[r] > totals[r]) {
                std::cout << "\033[31m  Error: Max " << RES_NAMES[r]
                          << " (" << maxClaim[r] << ") exceeds system total ("
                          << totals[r] << ").\033[0m\n";
                valid = false;
            }
        }
        if (valid) {
            int idx = banker_->addProcess(pid, name, maxClaim);
            std::cout << "\033[32m  Process registered at Banker index " << idx << "\033[0m\n";
            banker_->checkSafety();
        }
        pause();
    }

    /*
     * doBankerRequest()
     * Kernel admin simulates a resource request from a registered process.
     * Banker's Algorithm decides: GRANT (safe state) or DENY (unsafe).
     */
    void doBankerRequest() {
        std::cout << "\n  Banker's Resource Request\n";
        banker_->printState();
        std::cout << "\n  Process index (0-based from table above): ";
        int idx = readInt();
        std::vector<long long> req(NUM_RESOURCES);
        std::cout << "  Requesting RAM (MB) : "; req[0] = readInt();
        std::cout << "  Requesting Cores    : "; req[1] = readInt();
        std::cout << "  Requesting Seats    : "; req[2] = readInt();
        banker_->requestResources(idx, req);
        pause();
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  BOOT HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    void configureHardware() {
        std::cout << "  Use defaults? (RAM=2048MB, Cores=8, Seats=20) [y/n]: ";
        std::string ans; std::getline(std::cin, ans);
        if (ans == "n" || ans == "N") {
            std::cout << "  RAM (MB)    : "; std::cin >> cfg_.totalRAM_MB; std::cin.ignore();
            std::cout << "  CPU Cores   : "; std::cin >> cfg_.totalCores;  std::cin.ignore();
            std::cout << "  Total Seats : "; std::cin >> cfg_.totalSeats;  std::cin.ignore();
            // Rebuild railway with new seat count
        }
        railway_ = std::make_unique<RailwaySystem>(cfg_.totalSeats, ipc_);
        // Re-initialize Banker's Algorithm with final system totals
        banker_  = std::make_unique<BankersAlgorithm>(
            std::vector<long long>{cfg_.totalRAM_MB, cfg_.totalCores, cfg_.totalSeats});
        std::cout << "\n  \033[36mConfig: RAM=" << cfg_.totalRAM_MB
                  << "MB  Cores=" << cfg_.totalCores
                  << "  Seats=" << cfg_.totalSeats << "\033[0m\n\n";
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SHUTDOWN
    // ══════════════════════════════════════════════════════════════════════════

    void shutdown() {
        clear();
        std::cout << "\n\033[33m  Flushing data to disk...\033[0m";
        dot("");
        LOG("OS: Graceful shutdown");
        Logger::get().close();
        std::cout << "\033[32m  All data saved. System halted.\033[0m\n\n";
        running_ = false;
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  UI UTILITIES
    // ══════════════════════════════════════════════════════════════════════════

    void banner() {
        std::cout << R"(
  +----------------------------------------------+
  |         Mini OS Simulator  v2.0              |
  |   Concurrent Railway Reservation System      |
  |            OS Lab Final Project              |
  +----------------------------------------------+
)" << "\n";
    }

    void statusBar() {
        std::string m = (mode_ == SystemMode::USER)
            ? "\033[32m[USER MODE]\033[0m" : "\033[31m[KERNEL MODE]\033[0m";
        std::cout << m
                  << "  Algo: \033[36m" << scheduler_.algoName() << "\033[0m"
                  << "  Queue: \033[33m" << pm_.queueSize() << "\033[0m\n";
        std::cout << std::string(52, '-') << "\n";
    }

    void clear() { std::cout << "\033[2J\033[1;1H"; }

    void dot(const std::string& label) {
        if (!label.empty()) std::cout << label;
        for (int i = 0; i < 3; i++) {
            std::cout << "." << std::flush;
            std::this_thread::sleep_for(std::chrono::milliseconds(250));
        }
        std::cout << " \033[32mOK\033[0m\n";
    }

    void pause() {
        std::cout << "\n  Press Enter to continue...";
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    int readInt() {
        std::string line;
        std::getline(std::cin, line);
        try { return std::stoi(line); } catch (...) { return -1; }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  MEMBER DATA
    // ══════════════════════════════════════════════════════════════════════════
    SystemConfig     cfg_;
    ResourceManager  rm_;
    ProcessManager   pm_;
    Scheduler        scheduler_;
    IPCChannel       ipc_;
    InterruptHandler intHandler_;
    std::unique_ptr<RailwaySystem>   railway_;
    std::unique_ptr<BankersAlgorithm> banker_;
    SystemMode       mode_;
    bool             running_;
};

// ─────────────────────────────────────────────────────────────────────────────
int main() {
    MiniOS os;
    os.boot();
    os.run();
    return 0;
}
