/*
 * banker.h
 * ─────────────────────────────────────────────────────────────────────────────
 * BONUS: Deadlock Avoidance using Banker's Algorithm
 *        + Deadlock Prevention using Resource Ordering
 *
 * This file implements two classic OS deadlock handling strategies:
 *
 * 1. BankersAlgorithm  – Dijkstra's Banker's Algorithm
 *    - Tracks Allocation, Max, Need matrices for N processes × R resources
 *    - Safety Algorithm: finds a safe sequence (if one exists)
 *    - Resource-Request Algorithm: before granting any request, checks
 *      whether the resulting state would still be safe.
 *    - Resources modelled: RAM (MB), CPU Cores, Seats (3 resource types)
 *
 * 2. DeadlockPrevention – Resource Ordering (Coffman condition elimination)
 *    - Assigns a global order to resource types (RAM < Core < Seat)
 *    - Processes must always request resources in this strict order
 *    - Eliminates "Circular Wait" condition → deadlock impossible by design
 *    - Tracks attempted out-of-order requests and rejects them
 *
 * Integration with Mini OS:
 *    - BankersAlgorithm::requestResources() is called BEFORE ResourceManager
 *      allocates anything; if unsafe, the request is denied.
 *    - DeadlockPrevention::requestInOrder() enforces ordering at request time.
 * ─────────────────────────────────────────────────────────────────────────────
 */
#pragma once

#include "os_core.h"
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>

// ═══════════════════════════════════════════════════════════════════════════════
//  RESOURCE TYPE CONSTANTS  (3 resource types in our OS)
// ═══════════════════════════════════════════════════════════════════════════════
static const int NUM_RESOURCES = 3;
static const std::string RES_NAMES[NUM_RESOURCES] = { "RAM(MB)", "Cores", "Seats" };

// ═══════════════════════════════════════════════════════════════════════════════
//  BANKER'S ALGORITHM
// ═══════════════════════════════════════════════════════════════════════════════
class BankersAlgorithm {
public:
    /*
     * Constructor
     * totalRes[i] = total units of resource i available in the system.
     * e.g. totalRes = {2048, 8, 20}  →  2048 MB RAM, 8 Cores, 20 Seats
     */
    explicit BankersAlgorithm(const std::vector<long long>& totalRes)
        : total_(totalRes), avail_(totalRes) {}

    // ── Register a new process with its Maximum resource claim ────────────────
    /*
     * addProcess()
     * pid    : process ID (for display)
     * name   : human-readable label
     * maxClaim[i] : maximum units of resource i this process will EVER need.
     * Returns process index in internal table (not the OS PID).
     * Initial allocation is zero (process just declared its max).
     */
    int addProcess(int pid, const std::string& name,
                   const std::vector<long long>& maxClaim) {
        ProcessEntry e;
        e.pid        = pid;
        e.name       = name;
        e.maxClaim   = maxClaim;
        e.allocation = std::vector<long long>(NUM_RESOURCES, 0);
        e.need       = maxClaim;   // need = max − allocation  (initially = max)
        e.finished   = false;
        table_.push_back(e);
        LOG("BANKER: Registered PID=" + std::to_string(pid)
            + " max=[" + vecStr(maxClaim) + "]");
        return (int)table_.size() - 1;
    }

    // ── Resource Request Algorithm ────────────────────────────────────────────
    /*
     * requestResources()
     * idx     : internal process index (from addProcess return value)
     * request : units of each resource being requested NOW
     *
     * Steps (Banker's Resource-Request Algorithm):
     *   1. Check request ≤ need   (can't ask for more than declared max)
     *   2. Check request ≤ avail  (enough free resources right now?)
     *   3. Pretend to allocate (update avail, allocation, need)
     *   4. Run Safety Algorithm on the pretend state
     *   5. If SAFE  → keep allocation, return true
     *      If UNSAFE → roll back, return false (deadlock would occur)
     */
    bool requestResources(int idx, const std::vector<long long>& request) {
        if (idx < 0 || idx >= (int)table_.size()) return false;
        ProcessEntry& p = table_[idx];

        // Step 1 – request must not exceed need
        for (int i = 0; i < NUM_RESOURCES; i++) {
            if (request[i] > p.need[i]) {
                std::cout << "\033[31m  [BANKER] ERROR: PID=" << p.pid
                          << " requests more than its declared max for "
                          << RES_NAMES[i] << "!\033[0m\n";
                LOG("BANKER: PID=" + std::to_string(p.pid)
                    + " request exceeds max – DENIED");
                return false;
            }
        }

        // Step 2 – request must not exceed available
        for (int i = 0; i < NUM_RESOURCES; i++) {
            if (request[i] > avail_[i]) {
                std::cout << "\033[33m  [BANKER] PID=" << p.pid
                          << " must wait – not enough " << RES_NAMES[i]
                          << " (need " << request[i]
                          << ", avail " << avail_[i] << ")\033[0m\n";
                LOG("BANKER: PID=" + std::to_string(p.pid)
                    + " waiting – insufficient " + RES_NAMES[i]);
                return false;
            }
        }

        // Step 3 – pretend to allocate
        for (int i = 0; i < NUM_RESOURCES; i++) {
            avail_[i]        -= request[i];
            p.allocation[i]  += request[i];
            p.need[i]        -= request[i];
        }

        // Step 4 – run safety check
        std::vector<int> safeSeq;
        bool safe = isSafe(safeSeq);

        if (safe) {
            std::cout << "\033[32m  [BANKER] Request GRANTED – system remains SAFE\033[0m\n";
            std::cout << "  Safe sequence: ";
            for (int si : safeSeq)
                std::cout << "P" << table_[si].pid << "(" << table_[si].name << ") ";
            std::cout << "\n";
            LOG("BANKER: PID=" + std::to_string(p.pid)
                + " GRANTED. Safe seq=[" + seqStr(safeSeq) + "]");
        } else {
            // Step 5 – roll back (unsafe state – would lead to deadlock)
            for (int i = 0; i < NUM_RESOURCES; i++) {
                avail_[i]        += request[i];
                p.allocation[i]  -= request[i];
                p.need[i]        += request[i];
            }
            std::cout << "\033[31m  [BANKER] Request DENIED – granting would cause UNSAFE state (deadlock risk)\033[0m\n";
            LOG("BANKER: PID=" + std::to_string(p.pid)
                + " DENIED – unsafe state");
        }
        return safe;
    }

    // ── Release resources when process finishes ───────────────────────────────
    /*
     * releaseResources()
     * Called when process terminates; returns all held resources to available.
     */
    void releaseResources(int idx) {
        if (idx < 0 || idx >= (int)table_.size()) return;
        ProcessEntry& p = table_[idx];
        for (int i = 0; i < NUM_RESOURCES; i++) {
            avail_[i]       += p.allocation[i];
            p.allocation[i]  = 0;
            p.need[i]        = 0;
        }
        p.finished = true;
        LOG("BANKER: PID=" + std::to_string(p.pid) + " released all resources");
    }

    // ── Run-only Safety Algorithm (check current state) ───────────────────────
    /*
     * checkSafety()
     * Public wrapper: runs safety algorithm on CURRENT (real) state.
     * Prints the safe sequence if one exists, or "UNSAFE" otherwise.
     * Called from the kernel menu to inspect system health.
     */
    void checkSafety() {
        std::vector<int> seq;
        bool safe = isSafe(seq);
        std::cout << "\n  \033[1mBanker's Algorithm – Safety Check\033[0m\n";
        std::cout << "  " << std::string(44, '-') << "\n";
        printState();
        std::cout << "\n  ";
        if (safe) {
            std::cout << "\033[32m✓ SAFE STATE\033[0m  Safe sequence: ";
            for (int si : seq)
                std::cout << "P" << table_[si].pid
                          << "(" << table_[si].name << ") → ";
            std::cout << "DONE\n";
        } else {
            std::cout << "\033[31m✗ UNSAFE STATE – deadlock risk detected!\033[0m\n";
        }
        std::cout << "\n";
        LOG("BANKER: Safety check result=" + std::string(safe ? "SAFE" : "UNSAFE"));
    }

    // ── Interactive demo: pre-loads example processes and runs algorithm ──────
    /*
     * runDemo()
     * Loads a textbook Banker's Algorithm example with 3 resource types
     * (RAM, Cores, Seats) and 4 processes. Shows:
     *   - Initial state table (Allocation, Max, Need, Available)
     *   - Safety algorithm execution step by step
     *   - One SAFE request (granted) and one UNSAFE request (denied)
     */
    void runDemo(const std::vector<long long>& systemTotal) {
        // Fresh demo instance with given system resources
        BankersAlgorithm demo(systemTotal);

        std::cout << "\n\033[36m  ══════════════════════════════════════════\033[0m\n";
        std::cout << "\033[36m  BANKER'S ALGORITHM DEMO\033[0m\n";
        std::cout << "\033[36m  Resources: RAM=" << systemTotal[0]
                  << "MB  Cores=" << systemTotal[1]
                  << "  Seats=" << systemTotal[2] << "\033[0m\n";
        std::cout << "\033[36m  ══════════════════════════════════════════\033[0m\n\n";

        // Register 4 example processes with max claims
        // Max claims chosen so that a safe sequence EXISTS initially
        int i0 = demo.addProcess(101, "BookingA", {300, 2, 3});
        int i1 = demo.addProcess(102, "BookingB", {600, 3, 2});
        int i2 = demo.addProcess(103, "ViewSeat",  {150, 1, 1});
        demo.addProcess(104, "CancelOp",  {200, 2, 2});

        // Simulate some initial allocations already given
        demo.avail_[0] -= 450; demo.table_[i0].allocation[0] = 200;
        demo.table_[i0].need[0] = 100;
        demo.avail_[1] -= 3;   demo.table_[i1].allocation[1] = 2;
        demo.table_[i1].need[1] = 1;
        demo.avail_[2] -= 2;   demo.table_[i2].allocation[2] = 1;
        demo.table_[i2].need[2] = 0;
        demo.table_[i1].allocation[0] = 250;
        demo.table_[i1].need[0] = 350;

        std::cout << "  \033[33mStep 1: Current State\033[0m\n";
        demo.checkSafety();

        std::cout << "  \033[33mStep 2: Safe Request – BookingA asks {100MB, 0 Cores, 1 Seat}\033[0m\n";
        bool r1 = demo.requestResources(i0, {100, 0, 1});
        std::cout << "  Result: " << (r1 ? "\033[32mGRANTED\033[0m" : "\033[31mDENIED\033[0m") << "\n\n";

        std::cout << "  \033[33mStep 3: Unsafe Request – BookingB asks {400MB, 2 Cores, 0 Seats}\033[0m\n";
        bool r2 = demo.requestResources(i1, {400, 2, 0});
        std::cout << "  Result: " << (r2 ? "\033[32mGRANTED\033[0m" : "\033[31mDENIED\033[0m") << "\n\n";

        std::cout << "  \033[33mStep 4: ViewSeat finishes – releases resources\033[0m\n";
        demo.releaseResources(i2);
        std::cout << "\n";
        demo.checkSafety();

        LOG("BANKER: Demo complete");
    }

    // ── Print full state table ─────────────────────────────────────────────────
    void printState() const {
        if (table_.empty()) {
            std::cout << "  No processes registered with Banker's Algorithm.\n";
            return;
        }
        // Header
        printf("  %-5s %-12s", "PID", "Name");
        for (int r = 0; r < NUM_RESOURCES; r++)
            printf(" Alloc[%s]", RES_NAMES[r].c_str());
        for (int r = 0; r < NUM_RESOURCES; r++)
            printf("  Max[%s]", RES_NAMES[r].c_str());
        for (int r = 0; r < NUM_RESOURCES; r++)
            printf(" Need[%s]", RES_NAMES[r].c_str());
        printf("\n");
        printf("  %-5s %-12s", "-----", "------------");
        for (int r = 0; r < NUM_RESOURCES * 3; r++) printf(" ----------");
        printf("\n");

        for (const auto& p : table_) {
            printf("  %-5d %-12s", p.pid, p.name.c_str());
            for (int r = 0; r < NUM_RESOURCES; r++)
                printf(" %-10lld", p.allocation[r]);
            for (int r = 0; r < NUM_RESOURCES; r++)
                printf(" %-10lld", p.maxClaim[r]);
            for (int r = 0; r < NUM_RESOURCES; r++)
                printf(" %-10lld", p.need[r]);
            printf("\n");
        }
        printf("  Available: ");
        for (int r = 0; r < NUM_RESOURCES; r++)
            printf("%s=%lld  ", RES_NAMES[r].c_str(), avail_[r]);
        printf("\n");
    }

    // ── GUI helpers ────────────────────────────────────────────────────────────
    /*
     * These three methods expose internal state to GraphicsUI (graphics.h)
     * without granting full access to private members.
     * All return value copies so the GUI thread is safe after the call.
     */

    // Row data for GraphicsUI::drawBankerState()
    struct GUIRow {
        int                    pid;
        std::string            name;
        std::vector<long long> alloc;
        std::vector<long long> max;
        std::vector<long long> need;
        bool                   finished;
    };

    std::vector<GUIRow> getRows() const {
        std::vector<GUIRow> out;
        for (const auto& p : table_) {
            GUIRow r;
            r.pid      = p.pid;
            r.name     = p.name;
            r.alloc    = p.allocation;
            r.max      = p.maxClaim;
            r.need     = p.need;
            r.finished = p.finished;
            out.push_back(r);
        }
        return out;
    }

    std::vector<long long> getAvail() const { return avail_; }

    /*
     * safetyInfo() – runs the safety algorithm and returns result + sequence
     * as a formatted string. Used by the GUI visualizer screen.
     */
    void safetyInfo(bool& outSafe, std::string& outSeq) const {
        std::vector<int> seq;
        outSafe = isSafe(seq);
        outSeq.clear();
        for (int idx : seq) {
            if (!outSeq.empty()) outSeq += " -> ";
            outSeq += "P" + std::to_string(table_[idx].pid)
                    + "(" + table_[idx].name + ")";
        }
        if (outSeq.empty()) outSeq = "(none)";
    }

private:
    // ── Safety Algorithm (Banker's core) ──────────────────────────────────────
    /*
     * isSafe()
     * Classic Banker's safety algorithm:
     *   work   = copy of available resources
     *   finish = false for all processes
     * Repeat:
     *   Find process i where !finish[i] AND need[i] ≤ work
     *   If found: work += allocation[i], finish[i] = true, add to safe sequence
     *   If not found: break
     * If all finish[i] == true → SAFE state; otherwise UNSAFE.
     */
    bool isSafe(std::vector<int>& safeSeq) const {
        int n = (int)table_.size();
        std::vector<long long> work = avail_;
        std::vector<bool>      finish(n, false);
        safeSeq.clear();

        // Mark already-finished processes
        for (int i = 0; i < n; i++)
            if (table_[i].finished) finish[i] = true;

        bool progress = true;
        while (progress) {
            progress = false;
            for (int i = 0; i < n; i++) {
                if (finish[i]) continue;
                // Check need[i] ≤ work
                bool canRun = true;
                for (int r = 0; r < NUM_RESOURCES; r++) {
                    if (table_[i].need[r] > work[r]) { canRun = false; break; }
                }
                if (canRun) {
                    // Simulate process finishing: release its allocation
                    for (int r = 0; r < NUM_RESOURCES; r++)
                        work[r] += table_[i].allocation[r];
                    finish[i] = true;
                    safeSeq.push_back(i);
                    progress = true;
                }
            }
        }

        // Check if all processes finished
        for (int i = 0; i < n; i++)
            if (!finish[i]) return false;
        return true;
    }

    std::string vecStr(const std::vector<long long>& v) const {
        std::string s;
        for (int i = 0; i < (int)v.size(); i++) {
            if (i) s += ",";
            s += std::to_string(v[i]);
        }
        return s;
    }

    std::string seqStr(const std::vector<int>& seq) const {
        std::string s;
        for (int idx : seq) {
            if (!s.empty()) s += "->";
            s += "P" + std::to_string(table_[idx].pid);
        }
        return s;
    }

    struct ProcessEntry {
        int                    pid;
        std::string            name;
        std::vector<long long> maxClaim;
        std::vector<long long> allocation;
        std::vector<long long> need;
        bool                   finished = false;
    };

    std::vector<long long>  total_;
    std::vector<long long>  avail_;
    std::vector<ProcessEntry> table_;
};


// ═══════════════════════════════════════════════════════════════════════════════
//  DEADLOCK PREVENTION – Resource Ordering (Circular Wait Elimination)
// ═══════════════════════════════════════════════════════════════════════════════
class DeadlockPrevention {
public:
    /*
     * Resource ordering:
     *   0 = RAM     (must be requested first)
     *   1 = Core    (second)
     *   2 = Seat    (last)
     *
     * Rule: A process may only request resource type R if it holds NO resource
     * of type R' where R' > R (i.e., no higher-order resource already held).
     * This eliminates the "Circular Wait" Coffman condition.
     */

    /*
     * requestInOrder()
     * pid         : process requesting resources
     * resourceType: 0=RAM, 1=Core, 2=Seat
     * heldTypes   : list of resource types this process currently holds
     *
     * Returns true if request is in the correct order (safe to proceed).
     * Returns false if the request would violate ordering (prevented).
     */
    static bool requestInOrder(int pid, int resourceType,
                               const std::vector<int>& heldTypes) {
        // Check: does the process hold any resource with ORDER > resourceType?
        for (int held : heldTypes) {
            if (held > resourceType) {
                std::cout << "\033[31m  [DEADLOCK PREV] PID=" << pid
                          << " REJECTED: Requesting " << RES_NAMES[resourceType]
                          << " but already holds " << RES_NAMES[held]
                          << " (violates resource ordering rule)\033[0m\n";
                LOG("DEADLOCK_PREV: PID=" + std::to_string(pid)
                    + " out-of-order request BLOCKED – holds " + RES_NAMES[held]
                    + " requesting " + RES_NAMES[resourceType]);
                return false;
            }
        }
        std::cout << "\033[32m  [DEADLOCK PREV] PID=" << pid
                  << " request for " << RES_NAMES[resourceType]
                  << " is in ORDER – allowed\033[0m\n";
        return true;
    }

    /*
     * runDemo()
     * Shows a step-by-step demonstration of resource ordering prevention.
     * Two scenarios:
     *   A) P1 requests RAM then Core (correct order)   → ALLOWED
     *   B) P2 holds Core then requests RAM (wrong order) → BLOCKED
     */
    static void runDemo() {
        std::cout << "\n\033[36m  ══════════════════════════════════════════\033[0m\n";
        std::cout << "\033[36m  DEADLOCK PREVENTION – Resource Ordering Demo\033[0m\n";
        std::cout << "\033[36m  ══════════════════════════════════════════\033[0m\n";
        std::cout << "\n  Resource Order: RAM(0) < Core(1) < Seat(2)\n";
        std::cout << "  Rule: Always request in ascending order only.\n\n";

        // Scenario A – correct order (RAM → Core → Seat)
        std::cout << "  \033[33mScenario A: P201 requests RAM (holds nothing)\033[0m\n";
        requestInOrder(201, 0, {});                   // RAM   – ok

        std::cout << "\n  \033[33mScenario A: P201 requests Core (holds RAM)\033[0m\n";
        requestInOrder(201, 1, {0});                  // Core  – ok (RAM < Core)

        std::cout << "\n  \033[33mScenario A: P201 requests Seat (holds RAM, Core)\033[0m\n";
        requestInOrder(201, 2, {0, 1});               // Seat  – ok (Core < Seat)

        std::cout << "\n  \033[33mScenario B: P202 holds Core, now requests RAM\033[0m\n";
        requestInOrder(202, 0, {1});                  // RAM   – BLOCKED (holds Core)

        std::cout << "\n  \033[33mScenario B: P203 holds Seat, now requests Core\033[0m\n";
        requestInOrder(203, 1, {2});                  // Core  – BLOCKED (holds Seat)

        std::cout << "\n\033[32m  Result: Circular wait is impossible with strict ordering.\033[0m\n";
        std::cout << "\033[32m  Deadlock is structurally prevented.\033[0m\n\n";

        LOG("DEADLOCK_PREV: Demo complete");
    }

    /*
     * printExplanation()
     * Prints the four Coffman conditions and explains which one
     * resource ordering eliminates.
     */
    static void printExplanation() {
        std::cout << "\n  \033[1mDeadlock Prevention via Resource Ordering\033[0m\n";
        std::cout << "  " << std::string(44, '-') << "\n\n";
        std::cout << "  The four Coffman conditions for deadlock:\n\n";
        std::cout << "  1. Mutual Exclusion  – [KEPT]   Resources non-shareable\n";
        std::cout << "  2. Hold & Wait       – [KEPT]   Process holds while waiting\n";
        std::cout << "  3. No Preemption     – [KEPT]   Resources not forcibly taken\n";
        std::cout << "  4. Circular Wait     – [BROKEN] <-- Our prevention target\n\n";
        std::cout << "  Strategy: Assign a global order to resource types:\n";
        std::cout << "    Type 0 = RAM   (lowest order)\n";
        std::cout << "    Type 1 = CPU Cores\n";
        std::cout << "    Type 2 = Seats (highest order)\n\n";
        std::cout << "  Rule enforced by OS: A process may only request resource\n";
        std::cout << "  type R if it currently holds NO resource of type > R.\n\n";
        std::cout << "  Why this breaks circular wait:\n";
        std::cout << "  If every process requests in ascending order, it is\n";
        std::cout << "  impossible to form a cycle in the resource-allocation graph.\n";
        std::cout << "  Therefore deadlock CANNOT occur.\n\n";
    }
};
