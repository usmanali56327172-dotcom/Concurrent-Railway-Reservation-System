/*
 * main_gui.cpp
 * ─────────────────────────────────────────────────────────────────────────────
 * BONUS: Graphical (ncurses TUI) Entry Point for Mini OS Simulator
 *
 * This file is an ALTERNATIVE to main.cpp — it runs the same OS subsystems
 * but wraps everything in the ncurses GraphicsUI layer from graphics.h.
 *
 * File structure:
 *   os_core.h       – shared types, PCB, Seat, SystemConfig, Logger
 *   os_subsystems.h – ResourceManager, ProcessManager, Scheduler, IPC, Interrupts
 *   railway.h       – Concurrent Railway Reservation System
 *   banker.h        – Banker's Algorithm + Deadlock Prevention  (BONUS)
 *   graphics.h      – ncurses TUI: boot splash, menus, dashboard (BONUS)
 *   main_gui.cpp    – THIS FILE: GUI MiniOS class + main()
 *
 * Compile: g++ -std=c++17 -pthread -O2 -o os_gui main_gui.cpp -lncurses
 * Run:     ./os_gui
 *
 * Note: The original terminal build still works:
 *   g++ -std=c++17 -pthread -O2 -o os_sim main.cpp
 * ─────────────────────────────────────────────────────────────────────────────
 */

#include "os_core.h"
#include "os_subsystems.h"
#include "railway.h"
#include "banker.h"
#include "graphics.h"
#include <thread>
#include <chrono>

// mkdir must come AFTER ncurses (graphics.h) to avoid macro conflicts
#ifdef __linux__
  #include <sys/stat.h>
  #include <sys/types.h>
#endif

// ─────────────────────────────────────────────────────────────────────────────
//  GUI MINI OS CLASS
//  Same OS logic as MiniOS in main.cpp, but all user-facing output goes
//  through GraphicsUI (ncurses windows) instead of raw std::cout.
// ─────────────────────────────────────────────────────────────────────────────
class GUIMiniOS {
public:
    GUIMiniOS()
        : rm_(cfg_),
          pm_(),
          scheduler_(pm_, rm_, cfg_),
          ipc_(),
          intHandler_(pm_),
          railway_(std::make_unique<RailwaySystem>(20, ipc_)),
          banker_(std::make_unique<BankersAlgorithm>(
              std::vector<long long>{2048, 8, 20})),
          mode_(SystemMode::USER),
          running_(false) {}

    // ── Boot ──────────────────────────────────────────────────────────────────
    /*
     * boot()
     * Initialises ncurses UI, shows animated splash, prompts for hardware
     * config, then starts OS subsystems. Logger writes to data/system_log.txt.
     */
    void boot() {
        mkdir("data", 0755);

        // GraphicsUI constructor calls initscr() so it must come first
        ui_ = std::make_unique<GraphicsUI>();

        // Hardware config via simple dialog before full boot animation
        configureHardware();

        // Animated boot splash
        ui_->boot(cfg_);

        Logger::get().init("data/system_log.txt");
        LOG("GUI-OS: Boot complete | RAM=" + std::to_string(cfg_.totalRAM_MB)
            + "MB | Cores=" + std::to_string(cfg_.totalCores)
            + " | Seats=" + std::to_string(cfg_.totalSeats));

        running_ = true;
    }

    // ── Main event loop ───────────────────────────────────────────────────────
    /*
     * run()
     * Repeatedly:
     *   1. Redraws the status bar (mode, algo, queue, RAM, cores)
     *   2. Shows the appropriate menu (user or kernel)
     *   3. Dispatches the chosen action
     *   4. Checks for shutdown signal
     */
    void run() {
        while (running_) {
            // Refresh status bar every iteration
            ui_->drawStatusBar(mode_, scheduler_.algoName(),
                               pm_.queueSize(),
                               cfg_.usedRAM_MB, cfg_.totalRAM_MB,
                               cfg_.usedCores, cfg_.totalCores);

            if (mode_ == SystemMode::USER)
                userMenu();
            else
                kernelMenu();

            if (intHandler_.shuttingDown()) {
                shutdown();
                return;
            }
        }
    }

private:
    // ═════════════════════════════════════════════════════════════════════════
    //  HARDWARE CONFIG  (runs before ncurses; uses plain cin/cout is not safe
    //  inside ncurses, so we use ncurses inputDialog instead)
    // ═════════════════════════════════════════════════════════════════════════
    /*
     * configureHardware()
     * Asks user via ncurses dialog whether to use default hardware values.
     * If 'n', shows individual dialogs for RAM, Cores, Seats.
     * Rebuilds RailwaySystem and BankersAlgorithm with final values.
     */
    void configureHardware() {
        // We need a temporary GraphicsUI before the real one (for the dialog)
        // But ui_ is not set yet here — so we do a quick pre-init dialog
        // by relying on the fact that GraphicsUI was already constructed above.
        // (boot() calls configureHardware() BEFORE ui_->boot())

        std::string ans = ui_->inputDialog("Hardware Configuration",
            "Use defaults? RAM=2048MB Cores=8 Seats=20  [y/n]");

        if (ans == "n" || ans == "N") {
            std::string r = ui_->inputDialog("RAM", "Total RAM in MB (e.g. 2048):");
            std::string c = ui_->inputDialog("Cores", "Total CPU Cores (e.g. 8):");
            std::string s = ui_->inputDialog("Seats", "Total Train Seats (e.g. 20):");
            try { cfg_.totalRAM_MB  = std::stoll(r); } catch (...) {}
            try { cfg_.totalCores   = std::stoi(c);  } catch (...) {}
            try { cfg_.totalSeats   = std::stoi(s);  } catch (...) {}
        }

        railway_ = std::make_unique<RailwaySystem>(cfg_.totalSeats, ipc_);
        banker_  = std::make_unique<BankersAlgorithm>(
            std::vector<long long>{cfg_.totalRAM_MB, cfg_.totalCores, cfg_.totalSeats});
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  USER MODE MENU
    // ═════════════════════════════════════════════════════════════════════════
    /*
     * userMenu()
     * Draws the passenger-facing Railway menu via GraphicsUI::menu().
     * Each option dispatches the corresponding OS action.
     */
    void userMenu() {
        const std::vector<std::string> items = {
            " 1.  Book Ticket",
            " 2.  Cancel Ticket",
            " 3.  View Dashboard  (Seats + Resources)",
            " 4.  View All Bookings",
            " 5.  Passenger Info Lookup",
            " 6.  Concurrent Booking Demo",
            " 7.  Multitasking Demo  (Multiple Processes)",
            " 8.  Process Table",
            " 9.  IPC Message Queue",
            "10.  Change Scheduling Algorithm",
            "11.  Switch to Kernel Mode",
            " 0.  Exit"
        };

        int ch = ui_->menu("Railway Reservation System", items, false);
        switch (ch) {
            case  1: doBook();          break;
            case  2: doCancel();        break;
            case  3: doDashboard();     break;
            case  4: doViewBookings();  break;
            case  5: doPassengerLookup(); break;
            case  6: doConcurrentDemo(); break;
            case  7: doMultitaskingDemo(); break;
            case  8: doProcessTable();  break;
            case  9: doIPCQueue();      break;
            case 10: doChangeAlgo();    break;
            case 11: doEnterKernel();   break;
            case  0: intHandler_.raise(InterruptType::SYSTEM_SHUTDOWN); break;
            default: break;
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  KERNEL MODE MENU
    // ═════════════════════════════════════════════════════════════════════════
    /*
     * kernelMenu()
     * Admin-only menu rendered with red border (isKernel=true).
     * Includes all standard kernel ops + the BONUS Banker's/Deadlock options.
     */
    void kernelMenu() {
        const std::vector<std::string> items = {
            " 1.  View Process Table",
            " 2.  Force-Terminate Process",
            " 3.  View Resource Dashboard",
            " 4.  Reset Seat Database",
            " 5.  Raise Interrupt",
            " 6.  Recover Blocked Processes",
            " 7.  View IPC Message Queue",
            " 8.  Write to IPC Pipe",
            " 9.  Read IPC Pipe",
            "10.  System Shutdown",
            "11.  Return to User Mode",
            "\xe2\x94\x80\xe2\x94\x80 BONUS \xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80",
            "12.  Banker's Algo  – Safety Check Visualizer",
            "13.  Banker's Algo  – Register Process",
            "14.  Banker's Algo  – Resource Request",
            "15.  Banker's Algo  – Full Demo",
            "16.  Deadlock Prev  – Explanation",
            "17.  Deadlock Prev  – Demo",
            "18.  Help Screen"
        };

        int ch = ui_->menu("KERNEL MODE", items, true);
        switch (ch) {
            case  1: doProcessTable();                   break;
            case  2: doKernelTerminate();                break;
            case  3: doDashboard();                      break;
            case  4: doResetSeats();                     break;
            case  5: doRaiseInterrupt();                 break;
            case  6: doUnblockProcesses();               break;
            case  7: doIPCQueue();                       break;
            case  8: doIPCWrite();                       break;
            case  9: doIPCRead();                        break;
            case 10: intHandler_.raise(InterruptType::SYSTEM_SHUTDOWN); break;
            case 11: mode_ = SystemMode::USER;
                     LOG("OS: -> USER mode");            break;
            case 12: doBankerSafetyVisualizer();         break;
            case 13: doBankerRegister();                 break;
            case 14: doBankerRequest();                  break;
            case 15: doBankerFullDemo();                 break;
            case 16: doDLPrevExplanation();              break;
            case 17: doDLPrevDemo();                     break;
            case 18: ui_->drawHelp();                    break;
            default: break;
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  USER ACTIONS
    // ═════════════════════════════════════════════════════════════════════════

    /*
     * doBook()
     * Prompts for passenger name, ID, seat number via dialogs.
     * Creates a PCB, enqueues it, dispatches it through the scheduler.
     * The scheduler lambda calls RailwaySystem::bookTicket().
     * Result shown in a graphical msgBox (green=success, red=fail).
     */
    void doBook() {
        std::string name = ui_->inputDialog("Book Ticket", "Passenger Name:");
        std::string id   = ui_->inputDialog("Book Ticket", "Passenger ID:");
        int seat = ui_->inputInt("Book Ticket",
            "Seat No (1-" + std::to_string(railway_->totalSeats()) + "):");

        if (name.empty() || id.empty() || seat < 1) {
            ui_->msgBox(false, {"Invalid input – booking cancelled."});
            return;
        }

        int pid = pm_.createProcess(name, "BOOK", 64, 100, 1);
        pm_.makeReady(pid);

        bool result = false;
        scheduler_.dispatch([&](PCB& pcb) {
            result = railway_->bookTicket(seat, name, id, pcb.pid);
        });

        if (result)
            ui_->msgBox(true,  {"Seat " + std::to_string(seat) + " booked for " + name,
                                "PID=" + std::to_string(pid)});
        else
            ui_->msgBox(false, {"Booking FAILED for seat " + std::to_string(seat),
                                "Seat may already be booked or invalid."});
    }

    /*
     * doCancel()
     * Prompts for seat number. Creates a CANCEL process, raises
     * TICKET_CANCEL interrupt, dispatches cancellation via scheduler.
     */
    void doCancel() {
        int seat = ui_->inputInt("Cancel Ticket", "Seat No to cancel:");
        if (seat < 1) { ui_->msgBox(false, {"Invalid seat number."}); return; }

        int pid = pm_.createProcess("CancelReq", "CANCEL", 32, 50, 2);
        pm_.makeReady(pid);
        intHandler_.raise(InterruptType::TICKET_CANCEL);

        bool result = false;
        scheduler_.dispatch([&](PCB& pcb) {
            intHandler_.handle(pcb.pid);
            result = railway_->cancelTicket(seat, pcb.pid);
        });

        if (result)
            ui_->msgBox(true,  {"Seat " + std::to_string(seat) + " cancellation done."});
        else
            ui_->msgBox(false, {"Cancellation FAILED – seat not booked or invalid."});
    }

    /*
     * doDashboard()
     * Collects current seat vector snapshot and renders the full
     * GraphicsUI resource dashboard (RAM bar, core grid, seat map).
     */
    void doDashboard() {
        // Collect seat snapshot by viewing available (temporarily redirect)
        // We expose seats via a helper that returns a const ref
        // For simplicity, reconstruct from viewBookings output — use a local
        // seats snapshot built from the railway system query
        std::vector<Seat> snap = railway_->seatSnapshot();
        ui_->drawDashboard(cfg_, snap);
    }

    /*
     * doViewBookings()
     * Renders current bookings as a process-table style ncurses window
     * by converting seat data into PCBSnapshot-like rows.
     */
    void doViewBookings() {
        std::vector<Seat> snap = railway_->seatSnapshot();
        // Redirect console output to ncurses window
        // We reuse the dashboard which already shows bookings in the seat map
        ui_->drawDashboard(cfg_, snap);
    }

    void doPassengerLookup() {
        std::string q = ui_->inputDialog("Passenger Lookup", "Enter name or ID:");
        // Capture railway output into string then show in msgBox
        // Use a thread-safe redirect: execute in a separate context
        // For simplicity, temporarily restore terminal for this one call
        def_prog_mode();
        endwin();
        std::cout << "\n";
        railway_->passengerInfo(q);
        std::cout << "\n  Press Enter..."; std::cin.ignore(1024, '\n');
        reset_prog_mode();
        refresh();
    }

    /*
     * doConcurrentDemo()
     * Runs the RailwaySystem concurrent booking demo (6 threads).
     * Since this uses cout internally, we temporarily suspend ncurses,
     * run the demo in terminal mode, then restore ncurses.
     */
    void doConcurrentDemo() {
        def_prog_mode();
        endwin();
        std::cout << "\033[2J\033[1;1H";
        railway_->concurrentDemo(pm_, 6);
        std::cout << "\n  Press Enter to return to GUI...";
        std::cin.ignore(1024, '\n');
        reset_prog_mode();
        refresh();
    }

    /*
     * doMultitaskingDemo()
     * Creates 4 mixed processes (BOOK/VIEW/INFO) simultaneously,
     * shows them entering the Ready Queue, then dispatches each.
     * Final process table shown via GraphicsUI::drawProcessTable().
     */
    void doMultitaskingDemo() {
        def_prog_mode();
        endwin();
        std::cout << "\033[2J\033[1;1H";
        std::cout << "\n\033[36m  ══ MULTITASKING DEMO ══\033[0m\n\n";
        std::cout << "  Spawning 4 processes simultaneously...\n\n";
        LOG("MULTITASK DEMO: Starting");

        int p1 = pm_.createProcess("Alice",   "BOOK", 64,  120, 2);
        int p2 = pm_.createProcess("Bob",     "VIEW", 32,   60, 3);
        int p3 = pm_.createProcess("Charlie", "BOOK", 64,  120, 1);
        int p4 = pm_.createProcess("Diana",   "INFO", 32,   80, 2);

        pm_.makeReady(p1); pm_.makeReady(p2);
        pm_.makeReady(p3); pm_.makeReady(p4);
        std::cout << "  [QUEUE] 4 processes in Ready Queue.\n\n";

        scheduler_.dispatch([&](PCB& pcb){
            std::cout << "  [PID=" << pcb.pid << "] Alice -> BOOK seat 3\n";
            railway_->bookTicket(3,"Alice","A001",pcb.pid);});
        scheduler_.dispatch([&](PCB& pcb){
            std::cout << "  [PID=" << pcb.pid << "] Bob -> VIEW seats\n";
            railway_->viewAvailable();});
        scheduler_.dispatch([&](PCB& pcb){
            std::cout << "  [PID=" << pcb.pid << "] Charlie -> BOOK seat 4\n";
            railway_->bookTicket(4,"Charlie","C002",pcb.pid);});
        scheduler_.dispatch([&](PCB& pcb){
            std::cout << "  [PID=" << pcb.pid << "] Diana -> INFO lookup\n";
            railway_->passengerInfo("Alice");});

        LOG("MULTITASK DEMO: Complete");
        std::cout << "\n  Press Enter to return to GUI...";
        std::cin.ignore(1024, '\n');
        reset_prog_mode();
        refresh();
    }

    /*
     * doProcessTable()
     * Collects a PCBSnapshot vector from ProcessManager and renders
     * the color-coded process table in GraphicsUI.
     */
    void doProcessTable() {
        std::vector<PCB> snaps = pm_.getSnapshots();
        ui_->drawProcessTable(snaps, cfg_);
    }

    void doIPCQueue() {
        def_prog_mode(); endwin();
        ipc_.printMessageQueue();
        std::cout << "\n  Press Enter..."; std::cin.ignore(1024,'\n');
        reset_prog_mode(); refresh();
    }

    void doIPCWrite() {
        int from = ui_->inputInt("IPC Pipe Write", "Sender PID:");
        std::string msg = ui_->inputDialog("IPC Pipe Write", "Message:");
        ipc_.pipeWrite(from, msg);
        ui_->msgBox(true, {"Written to IPC pipe.", "From PID=" + std::to_string(from)});
    }

    void doIPCRead() {
        int pid = ui_->inputInt("IPC Pipe Read", "Reader PID:");
        std::string data = ipc_.pipeRead(pid);
        ui_->msgBox(true, {"Pipe contents:", data}, 0);
    }

    void doChangeAlgo() {
        const std::vector<std::string> items = {
            " 1. FCFS",
            " 2. Round Robin",
            " 3. Priority"
        };
        int ch = ui_->menu("Change Scheduling Algorithm", items, false);
        switch (ch) {
            case 1: scheduler_.setAlgo(SchedulingAlgo::FCFS);        break;
            case 2: scheduler_.setAlgo(SchedulingAlgo::ROUND_ROBIN); break;
            case 3: scheduler_.setAlgo(SchedulingAlgo::PRIORITY);    break;
        }
        ui_->msgBox(true, {"Algorithm set to: " + scheduler_.algoName()}, 800);
    }

    void doEnterKernel() {
        std::string pw = ui_->inputDialog("Kernel Mode Access", "Enter kernel password:");
        if (pw == "kernel123") {
            mode_ = SystemMode::KERNEL;
            LOG("OS: -> KERNEL mode");
            ui_->msgBox(true, {"Kernel mode activated."}, 600);
        } else {
            ui_->msgBox(false, {"Access denied. Wrong password."});
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  KERNEL ACTIONS
    // ═════════════════════════════════════════════════════════════════════════

    void doKernelTerminate() {
        int pid = ui_->inputInt("Force Terminate", "Enter PID to terminate:");
        if (pm_.forceTerminate(pid))
            ui_->msgBox(true,  {"PID " + std::to_string(pid) + " terminated."});
        else
            ui_->msgBox(false, {"PID not found or already terminated."});
    }

    void doResetSeats() {
        railway_->resetAll();
        ui_->msgBox(true, {"All seats have been reset."}, 800);
    }

    void doRaiseInterrupt() {
        const std::vector<std::string> items = {
            " 1. TICKET_CANCEL",
            " 2. BOOKING_TIMEOUT",
            " 3. SYSTEM_SHUTDOWN"
        };
        int ch = ui_->menu("Raise Interrupt", items, true);
        switch (ch) {
            case 1: intHandler_.raise(InterruptType::TICKET_CANCEL);   break;
            case 2: intHandler_.raise(InterruptType::BOOKING_TIMEOUT); break;
            case 3: intHandler_.raise(InterruptType::SYSTEM_SHUTDOWN); break;
        }
        if (ch >= 1 && ch <= 3)
            ui_->msgBox(true, {"Interrupt raised."}, 600);
    }

    void doUnblockProcesses() {
        int n = intHandler_.unblockProcesses();
        ui_->msgBox(n > 0,
            {std::to_string(n) + " BLOCKED process(es) recovered to READY."}, 800);
    }

    // ── BONUS: Banker's Algorithm GUI actions ─────────────────────────────────

    /*
     * doBankerSafetyVisualizer()
     * Pulls current Banker state and renders it via GraphicsUI::drawBankerState().
     * Shows safe sequence visually if safe, red alert if unsafe.
     */
    void doBankerSafetyVisualizer() {
        auto rows  = banker_->getRows();
        auto avail = banker_->getAvail();
        bool safe;
        std::string seq;
        banker_->safetyInfo(safe, seq);
        ui_->drawBankerState(rows, avail, safe, seq);
    }

    void doBankerRegister() {
        int pid = ui_->inputInt("Banker – Register", "PID:");
        std::string name = ui_->inputDialog("Banker – Register", "Process name:");
        long long r = ui_->inputInt("Banker – Max Claim", "Max RAM (MB):");
        long long c = ui_->inputInt("Banker – Max Claim", "Max Cores:");
        long long s = ui_->inputInt("Banker – Max Claim", "Max Seats:");

        std::vector<long long> maxClaim = {r, c, s};
        std::vector<long long> totals   = {cfg_.totalRAM_MB, cfg_.totalCores, cfg_.totalSeats};
        bool valid = true;
        for (int i = 0; i < NUM_RESOURCES; i++) {
            if (maxClaim[i] < 0 || maxClaim[i] > totals[i]) {
                ui_->msgBox(false, {"Max " + std::string(RES_NAMES[i]) +
                    " exceeds system total (" + std::to_string(totals[i]) + ")"}); 
                valid = false; break;
            }
        }
        if (valid) {
            int idx = banker_->addProcess(pid, name, maxClaim);
            ui_->msgBox(true, {"Process registered at Banker index " + std::to_string(idx)}, 800);
        }
    }

    void doBankerRequest() {
        int idx = ui_->inputInt("Banker – Request", "Process index (0-based):");
        long long r = ui_->inputInt("Banker – Request", "Request RAM (MB):");
        long long c = ui_->inputInt("Banker – Request", "Request Cores:");
        long long s = ui_->inputInt("Banker – Request", "Request Seats:");
        bool granted = banker_->requestResources(idx, {r, c, s});
        ui_->msgBox(granted,
            {granted ? "Request GRANTED – system is SAFE."
                     : "Request DENIED – would cause UNSAFE state."});
    }

    void doBankerFullDemo() {
        def_prog_mode(); endwin();
        std::cout << "\033[2J\033[1;1H";
        banker_->runDemo({cfg_.totalRAM_MB, cfg_.totalCores, cfg_.totalSeats});
        std::cout << "\n  Press Enter to return to GUI...";
        std::cin.ignore(1024, '\n');
        reset_prog_mode(); refresh();
    }

    void doDLPrevExplanation() {
        def_prog_mode(); endwin();
        std::cout << "\033[2J\033[1;1H";
        DeadlockPrevention::printExplanation();
        std::cout << "\n  Press Enter to return to GUI...";
        std::cin.ignore(1024, '\n');
        reset_prog_mode(); refresh();
    }

    void doDLPrevDemo() {
        def_prog_mode(); endwin();
        std::cout << "\033[2J\033[1;1H";
        DeadlockPrevention::runDemo();
        std::cout << "\n  Press Enter to return to GUI...";
        std::cin.ignore(1024, '\n');
        reset_prog_mode(); refresh();
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  SHUTDOWN
    // ═════════════════════════════════════════════════════════════════════════
    void shutdown() {
        ui_->shutdownAnim();
        LOG("OS: Graceful shutdown");
        Logger::get().close();
        running_ = false;
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  MEMBER DATA
    // ═════════════════════════════════════════════════════════════════════════
    SystemConfig                       cfg_;
    ResourceManager                    rm_;
    ProcessManager                     pm_;
    Scheduler                          scheduler_;
    IPCChannel                         ipc_;
    InterruptHandler                   intHandler_;
    std::unique_ptr<RailwaySystem>     railway_;
    std::unique_ptr<BankersAlgorithm>  banker_;
    std::unique_ptr<GraphicsUI>        ui_;
    SystemMode                         mode_;
    bool                               running_;
};

// ─────────────────────────────────────────────────────────────────────────────
int main() {
    GUIMiniOS os;
    os.boot();
    os.run();
    return 0;
}
