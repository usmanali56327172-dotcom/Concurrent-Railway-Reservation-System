/*
 * os_core.h
 * ─────────────────────────────────────────────────────────────────────────────
 * Central header for the Mini OS Simulator.
 * Contains ALL shared types, data structures, and the Logger.
 * Kept in one file so students can read the full OS data-model in one place
 * without jumping between eight separate headers.
 * ─────────────────────────────────────────────────────────────────────────────
 */
#pragma once

#include <string>
#include <fstream>
#include <mutex>
#include <ctime>
#include <iostream>
#include <atomic>

// ═══════════════════════════════════════════════════════════════════════════════
//  ENUMERATIONS
// ═══════════════════════════════════════════════════════════════════════════════

// All five standard OS process states
enum class ProcessState { NEW, READY, RUNNING, BLOCKED, TERMINATED };

// CPU scheduling algorithms implemented in this simulator
enum class SchedulingAlgo { FCFS, ROUND_ROBIN, PRIORITY };

// Execution privilege level
enum class SystemMode { USER, KERNEL };

// Interrupt types the OS can handle
enum class InterruptType { NONE, TICKET_CANCEL, BOOKING_TIMEOUT, SYSTEM_SHUTDOWN };

// ═══════════════════════════════════════════════════════════════════════════════
//  DATA STRUCTURES
// ═══════════════════════════════════════════════════════════════════════════════

/*
 * PCB – Process Control Block
 * The OS representation of a running or queued process.
 * Every passenger request creates one PCB.
 */
struct PCB {
    int          pid           = -1;
    std::string  name;
    ProcessState state         = ProcessState::NEW;
    int          priority      = 1;      // 1 = highest; used by Priority scheduler
    int          burstTime     = 150;    // total simulated CPU time (ms)
    int          remainingTime = 150;    // decremented by Round Robin
    int          memoryMB      = 64;     // RAM this process needs
    int          cpuCore       = -1;     // core assigned at dispatch time
    std::string  action;                 // "BOOK" | "CANCEL" | "VIEW" | "INFO"
    std::string  passengerName;
    std::string  passengerID;
    int          seatRequested = -1;
};

/*
 * Seat – one row in the shared seat database
 * Stored in a vector<Seat> that acts as shared memory between threads.
 */
struct Seat {
    int         number   = 0;
    bool        booked   = false;
    std::string passenger;
    std::string pid_owner;   // string of PID that booked this seat
};

/*
 * SystemConfig – hardware resource values
 * Populated at boot (user input or defaults).
 */
struct SystemConfig {
    long long totalRAM_MB   = 2048;   // 2 GB
    long long usedRAM_MB    = 256;    // 256 MB consumed by OS itself
    long long totalDisk_GB  = 256;
    int       totalCores    = 8;
    int       usedCores     = 0;
    int       totalSeats    = 20;
    int       timeQuantum   = 200;    // ms – Round Robin time slice
};

// ═══════════════════════════════════════════════════════════════════════════════
//  HELPERS
// ═══════════════════════════════════════════════════════════════════════════════

inline std::string stateStr(ProcessState s) {
    switch (s) {
        case ProcessState::NEW:        return "NEW";
        case ProcessState::READY:      return "READY";
        case ProcessState::RUNNING:    return "RUNNING";
        case ProcessState::BLOCKED:    return "BLOCKED";
        case ProcessState::TERMINATED: return "TERMINATED";
        default:                       return "UNKNOWN";
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
//  LOGGER  (thread-safe, singleton)
// ═══════════════════════════════════════════════════════════════════════════════

/*
 * Logger
 * Writes timestamped entries to both the terminal (dimmed) and system_log.txt.
 * Uses a mutex so concurrent threads don't interleave log lines.
 */
class Logger {
public:
    static Logger& get() {
        static Logger inst;
        return inst;
    }

    void init(const std::string& path) {
        file_.open(path, std::ios::app);
        write("=== OS SESSION STARTED ===");
    }

    void write(const std::string& msg) {
        std::lock_guard<std::mutex> lk(mtx_);
        std::string entry = "[" + now() + "] " + msg;
        std::cout << "\033[90m" << entry << "\033[0m\n";
        if (file_.is_open()) file_ << entry << "\n";
    }

    void close() {
        write("=== OS SESSION ENDED ===");
        if (file_.is_open()) file_.close();
    }

private:
    Logger() = default;

    std::string now() {
        time_t t = time(nullptr);
        char buf[9];
        strftime(buf, sizeof(buf), "%H:%M:%S", localtime(&t));
        return buf;
    }

    std::mutex    mtx_;
    std::ofstream file_;
};

// Convenience macro used throughout the project
#define LOG(msg) Logger::get().write(msg)
