/*
 * railway.h
 * ─────────────────────────────────────────────────────────────────────────────
 * Concurrent Railway Reservation System
 *
 * Concurrency design:
 *   - Seat data lives in a shared vector<Seat> (simulated shared memory)
 *   - seatMutex_ protects the critical section (book / cancel)
 *   - A counting semaphore limits simultaneous booking threads to 5
 *   - Multiple passenger threads can call bookTicket() at the same time;
 *     the mutex ensures only one modifies seat state at a time,
 *     preventing double-booking entirely.
 *
 * Persistence:
 *   - All bookings are saved to data/bookings.txt after every change
 *   - Loaded back automatically on startup
 * ─────────────────────────────────────────────────────────────────────────────
 */
#pragma once

#include "os_core.h"
#include "os_subsystems.h"
#include <vector>
#include <semaphore.h>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <thread>
#include <chrono>

class RailwaySystem {
public:
    RailwaySystem(int totalSeats, IPCChannel& ipc,
                  const std::string& dataFile = "data/bookings.txt")
        : ipc_(ipc), dataFile_(dataFile) {
        seats_.resize(totalSeats);
        for (int i = 0; i < totalSeats; i++)
            seats_[i].number = i + 1;
        // Semaphore allows up to 5 concurrent booking threads
        sem_init(&bookSem_, 0, 5);
        loadFromDisk();
        LOG("RAILWAY: Initialized with " + std::to_string(totalSeats) + " seats");
    }

    ~RailwaySystem() { sem_destroy(&bookSem_); }

    // ── 1. Book Ticket ────────────────────────────────────────────────────────
    /*
     * Thread-safe booking.
     * sem_wait() limits concurrency; mutex guards the critical section.
     * Returns true on success.
     */
    bool bookTicket(int seat, const std::string& name,
                    const std::string& id, int pid) {
        sem_wait(&bookSem_);   // acquire semaphore slot (max 5 concurrent)

        bool ok = false;
        {
            std::lock_guard<std::mutex> lk(seatMtx_);  // CRITICAL SECTION BEGIN
            if (seat < 1 || seat > (int)seats_.size()) {
                std::cout << "\033[31m  Error: Seat " << seat << " does not exist.\033[0m\n";
            } else if (seats_[seat - 1].booked) {
                std::cout << "\033[31m  Seat " << seat << " already booked. Double-booking prevented.\033[0m\n";
                LOG("RAILWAY: Double-booking attempt on seat " + std::to_string(seat)
                    + " by PID=" + std::to_string(pid));
                // Notify via IPC that seat is unavailable
                ipc_.sendMessage(pid, -1, "SEAT_UNAVAILABLE:" + std::to_string(seat));
            } else {
                seats_[seat - 1].booked    = true;
                seats_[seat - 1].passenger = name + " (" + id + ")";
                seats_[seat - 1].pid_owner = std::to_string(pid);
                ok = true;
                std::cout << "\033[32m  Seat " << seat << " booked for " << name << "\033[0m\n";
                LOG("RAILWAY: Seat " + std::to_string(seat) + " booked by " + name
                    + " PID=" + std::to_string(pid));
                ipc_.sendMessage(pid, -1, "BOOKED:seat=" + std::to_string(seat));
                saveToDisk();
            }
        }   // CRITICAL SECTION END

        sem_post(&bookSem_);   // release semaphore slot
        return ok;
    }

    // ── 2. Cancel Ticket ──────────────────────────────────────────────────────
    bool cancelTicket(int seat, int pid) {
        std::lock_guard<std::mutex> lk(seatMtx_);  // CRITICAL SECTION
        if (seat < 1 || seat > (int)seats_.size()) {
            std::cout << "\033[31m  Error: Invalid seat number.\033[0m\n";
            return false;
        }
        if (!seats_[seat - 1].booked) {
            std::cout << "\033[33m  Seat " << seat << " is not booked.\033[0m\n";
            return false;
        }
        std::string who = seats_[seat - 1].passenger;
        seats_[seat - 1].booked    = false;
        seats_[seat - 1].passenger = "";
        seats_[seat - 1].pid_owner = "";
        std::cout << "\033[32m  Seat " << seat << " cancelled (was: " << who << ")\033[0m\n";
        LOG("RAILWAY: Seat " + std::to_string(seat) + " cancelled by PID=" + std::to_string(pid));
        ipc_.sendMessage(pid, -1, "CANCELLED:seat=" + std::to_string(seat));
        saveToDisk();
        return true;
    }

    // ── 3. View Available Seats ───────────────────────────────────────────────
    void viewAvailable() const {
        std::lock_guard<std::mutex> lk(seatMtx_);
        int free = 0;
        std::cout << "\n  Seat Map  (\033[32m##\033[0m=Free  \033[31m##\033[0m=Booked):\n  ";
        for (int i = 0; i < (int)seats_.size(); i++) {
            if (seats_[i].booked)
                std::cout << "\033[31m[" << std::setw(2) << seats_[i].number << "]\033[0m ";
            else {
                std::cout << "\033[32m[" << std::setw(2) << seats_[i].number << "]\033[0m ";
                free++;
            }
            if ((i + 1) % 10 == 0) std::cout << "\n  ";
        }
        std::cout << "\n\n  Free=" << free << "  Booked=" << (int)seats_.size() - free
                  << "  Total=" << seats_.size() << "\n";
    }

    // ── 4. View Booking Status ────────────────────────────────────────────────
    void viewBookings() const {
        std::lock_guard<std::mutex> lk(seatMtx_);
        printf("\n  %-6s %-35s %s\n", "Seat", "Passenger (ID)", "PID");
        printf("  %-6s %-35s %s\n", "------", "-----------------------------------", "-----");
        bool any = false;
        for (const auto& s : seats_) {
            if (s.booked) {
                printf("  %-6d %-35s %s\n",
                       s.number, s.passenger.c_str(), s.pid_owner.c_str());
                any = true;
            }
        }
        if (!any) std::cout << "  No bookings yet.\n";
        std::cout << "\n";
    }

    // ── 5. Passenger Information ──────────────────────────────────────────────
    void passengerInfo(const std::string& query) const {
        std::lock_guard<std::mutex> lk(seatMtx_);
        bool found = false;
        for (const auto& s : seats_) {
            if (s.booked && s.passenger.find(query) != std::string::npos) {
                std::cout << "  Seat      : " << s.number   << "\n";
                std::cout << "  Passenger : " << s.passenger << "\n";
                std::cout << "  PID       : " << s.pid_owner << "\n\n";
                found = true;
            }
        }
        if (!found) std::cout << "  No record found for: " << query << "\n";
    }

    // ── Kernel: Reset all seats ───────────────────────────────────────────────
    void resetAll() {
        std::lock_guard<std::mutex> lk(seatMtx_);
        for (auto& s : seats_) {
            s.booked    = false;
            s.passenger = "";
            s.pid_owner = "";
        }
        saveToDisk();
        LOG("RAILWAY: All seats reset by kernel");
        std::cout << "\033[33m  All seats have been reset.\033[0m\n";
    }

    // ── Concurrent stress test: simulate N users booking simultaneously ────────
    /*
     * Demonstrates true concurrency: spawns N threads, each trying to book
     * a different seat at the same time. Mutex prevents any race condition.
     */
    void concurrentDemo(ProcessManager& pm, int numUsers = 5) {
        std::cout << "\n\033[36m  Starting concurrent booking demo with "
                  << numUsers << " simultaneous users...\033[0m\n";
        LOG("RAILWAY: Concurrent demo start, users=" + std::to_string(numUsers));

        std::vector<std::thread> threads;
        for (int i = 0; i < numUsers; i++) {
            threads.emplace_back([&, i]() {
                std::string uname = "AutoUser" + std::to_string(i + 1);
                std::string uid   = "AU" + std::to_string(100 + i);
                int seat = (i % (int)seats_.size()) + 1;

                int pid = pm.createProcess(uname, "BOOK", 64, 100, i + 1);
                pm.makeReady(pid);

                // Simulate slight timing variation between threads
                std::this_thread::sleep_for(std::chrono::milliseconds(i * 20));

                bookTicket(seat, uname, uid, pid);
                pm.setState(pid, ProcessState::TERMINATED);
            });
        }
        for (auto& t : threads) t.join();

        std::cout << "\033[32m  Concurrent demo complete. No double-bookings occurred.\033[0m\n\n";
        LOG("RAILWAY: Concurrent demo complete");
    }

    int totalSeats() const { return (int)seats_.size(); }

    /*
     * seatSnapshot() – returns a thread-safe copy of the seat vector.
     * Used by GraphicsUI::drawDashboard() to render the graphical seat map
     * without holding the railway mutex while painting ncurses windows.
     */
    std::vector<Seat> seatSnapshot() const {
        std::lock_guard<std::mutex> lk(seatMtx_);
        return seats_;   // value copy under lock
    }

private:
    // ── File persistence ──────────────────────────────────────────────────────
    void saveToDisk() {
        // Called inside critical section so no extra lock needed
        std::ofstream f(dataFile_);
        if (!f) return;
        f << "SEAT,PASSENGER,PID\n";
        for (const auto& s : seats_)
            if (s.booked)
                f << s.number << "," << s.passenger << "," << s.pid_owner << "\n";
    }

    void loadFromDisk() {
        std::ifstream f(dataFile_);
        if (!f) return;
        std::string line;
        std::getline(f, line); // skip header
        while (std::getline(f, line)) {
            std::istringstream ss(line);
            std::string tok;
            std::vector<std::string> parts;
            while (std::getline(ss, tok, ',')) parts.push_back(tok);
            if (parts.size() < 3) continue;
            int n = std::stoi(parts[0]);
            if (n < 1 || n > (int)seats_.size()) continue;
            seats_[n - 1].booked    = true;
            seats_[n - 1].passenger = parts[1];
            seats_[n - 1].pid_owner = parts[2];
        }
        LOG("RAILWAY: Loaded saved bookings from " + dataFile_);
    }

    mutable std::mutex  seatMtx_;   // guards the critical section
    sem_t               bookSem_;   // limits concurrent booking threads
    std::vector<Seat>   seats_;     // shared memory seat database
    IPCChannel&         ipc_;
    std::string         dataFile_;
};
